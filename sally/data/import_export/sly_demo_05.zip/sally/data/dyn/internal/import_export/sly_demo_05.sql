## Sally Database Dump Version 0.5
## Prefix sly05_
DROP TABLE IF EXISTS `sly05_article`;
CREATE TABLE `sly05_article` (
  `id` int(11) NOT NULL,
  `re_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `catname` varchar(255) NOT NULL,
  `catprior` int(11) NOT NULL,
  `attributes` text NOT NULL,
  `startpage` tinyint(1) NOT NULL,
  `prior` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `type` varchar(64) NOT NULL,
  `clang` int(11) NOT NULL,
  `createdate` int(11) NOT NULL,
  `updatedate` int(11) NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL DEFAULT '0',
  `wv24_fragment` varchar(64) NOT NULL,
  `wv24_skip` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`clang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `sly05_article` DISABLE KEYS */;
INSERT INTO `sly05_article` VALUES (1,0,'Was Sally für Sie tun','Was Sally für Sie tun',1,'',1,1,'|',1,'default',1,1312475175,1312475380,'admin','admin',0,'',0),(2,0,'Wie Sally für Sie arbeitet','Wie Sally für Sie arbeitet',2,'',1,1,'|',1,'default',1,1312475181,1312476040,'admin','admin',0,'',0),(3,0,'Was Sally einfach besser macht','Was Sally einfach besser macht',3,'',1,1,'|',1,'default',1,1312475188,1312475294,'admin','admin',0,'',0),(4,0,'Warum unsere Sally?','Warum unsere Sally?',4,'',1,1,'|',1,'default',1,1312475193,1312475297,'admin','admin',0,'',0),(5,0,'Antwort auf Ihre Fragen','Antwort auf Ihre Fragen',5,'',1,1,'|',1,'default',1,1312475199,1312475301,'admin','admin',0,'',0),(6,0,'Kontakt','',0,'',0,1,'|',1,'default',1,1312475207,1312475305,'admin','admin',0,'',0),(7,0,'Über Sally','',0,'',0,2,'|',1,'default',1,1312475211,1312475309,'admin','admin',0,'',0),(8,0,'Impressum','',0,'',0,3,'|',1,'default',1,1312475220,1312475311,'admin','admin',0,'',0);
/*!40000 ALTER TABLE `sly05_article` ENABLE KEYS */;

DROP TABLE IF EXISTS `sly05_article_slice`;
CREATE TABLE `sly05_article_slice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clang` int(11) NOT NULL,
  `slot` varchar(64) NOT NULL,
  `prior` int(5) NOT NULL,
  `slice_id` bigint(20) NOT NULL DEFAULT '0',
  `article_id` int(11) NOT NULL,
  `createdate` int(11) NOT NULL,
  `updatedate` int(11) NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `find_article` (`article_id`,`clang`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `sly05_article_slice` DISABLE KEYS */;
INSERT INTO `sly05_article_slice` VALUES (1,1,'main',0,1,1,1312475380,1312475380,'admin','admin',0),(2,1,'main',0,2,2,1312476040,1312476040,'admin','admin',0);
/*!40000 ALTER TABLE `sly05_article_slice` ENABLE KEYS */;

DROP TABLE IF EXISTS `sly05_clang`;
CREATE TABLE `sly05_clang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `revision` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `sly05_clang` DISABLE KEYS */;
INSERT INTO `sly05_clang` VALUES (1,'deutsch','de_DE',0);
/*!40000 ALTER TABLE `sly05_clang` ENABLE KEYS */;

DROP TABLE IF EXISTS `sly05_file`;
CREATE TABLE `sly05_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `re_file_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `attributes` text,
  `filetype` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `originalname` varchar(255) DEFAULT NULL,
  `filesize` varchar(255) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `createdate` int(11) NOT NULL,
  `updatedate` int(11) NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `filename` (`filename`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `sly05_file` DISABLE KEYS */;
INSERT INTO `sly05_file` VALUES (1,0,0,NULL,'image/jpeg','fish.jpg','fish.jpg','95731',500,375,'Triggerfish',1312476017,1312476017,'admin','admin',0),(2,0,0,NULL,'image/jpeg','fish2.jpg','fish2.jpg','110850',500,375,'The unknown Fish',1312476027,1312476027,'admin','admin',0);
/*!40000 ALTER TABLE `sly05_file` ENABLE KEYS */;

DROP TABLE IF EXISTS `sly05_file_category`;
CREATE TABLE `sly05_file_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `re_id` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `attributes` text,
  `createdate` int(11) NOT NULL,
  `updatedate` int(11) NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `sly05_registry`;
CREATE TABLE `sly05_registry` (
  `name` varchar(255) NOT NULL,
  `value` mediumtext,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `sly05_slice`;
CREATE TABLE `sly05_slice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `module` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `sly05_slice` DISABLE KEYS */;
INSERT INTO `sly05_slice` VALUES (1,'wymeditor'),(2,'image');
/*!40000 ALTER TABLE `sly05_slice` ENABLE KEYS */;

DROP TABLE IF EXISTS `sly05_slice_value`;
CREATE TABLE `sly05_slice_value` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `slice_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `finder` varchar(50) NOT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `slice_id` (`slice_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `sly05_slice_value` DISABLE KEYS */;
INSERT INTO `sly05_slice_value` VALUES (1,1,'SLY_VALUE','text','<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p><p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p><p>Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. </p><p>Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. </p><p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis. &#160;</p>'),(2,2,'SLY_MEDIA','image','fish2.jpg');
/*!40000 ALTER TABLE `sly05_slice_value` ENABLE KEYS */;

DROP TABLE IF EXISTS `sly05_wv24_cache`;
CREATE TABLE `sly05_wv24_cache` (
  `article_id` int(10) unsigned NOT NULL,
  `clang` smallint(4) unsigned NOT NULL,
  `path` varchar(32) NOT NULL,
  `url` varchar(2024) NOT NULL,
  `hash` int(10) unsigned NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`article_id`,`clang`),
  KEY `path` (`path`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `sly05_wv24_cache` DISABLE KEYS */;
INSERT INTO `sly05_wv24_cache` VALUES (1,1,'|','http://sally/releases/sally-v0.5.0-starterkit/sally/',1804046462,'2011-08-04 18:44:28'),(2,1,'|','http://sally/releases/sally-v0.5.0-starterkit/sally/wie-sally-fuer-sie-arbeitet/',1819405606,'2011-08-04 18:44:28'),(3,1,'|','http://sally/releases/sally-v0.5.0-starterkit/sally/was-sally-einfach-besser-macht/',917423222,'2011-08-04 18:44:28'),(4,1,'|','http://sally/releases/sally-v0.5.0-starterkit/sally/warum-unsere-sally/',921746632,'2011-08-04 18:44:28'),(5,1,'|','http://sally/releases/sally-v0.5.0-starterkit/sally/antwort-auf-ihre-fragen/',2147483647,'2011-08-04 18:44:28'),(6,1,'|','http://sally/releases/sally-v0.5.0-starterkit/sally/kontakt.html',257172803,'2011-08-04 18:44:28'),(7,1,'|','http://sally/releases/sally-v0.5.0-starterkit/sally/ueber-sally.html',2147483647,'2011-08-04 18:44:28'),(8,1,'|','http://sally/releases/sally-v0.5.0-starterkit/sally/impressum.html',2147483647,'2011-08-04 18:44:28');
/*!40000 ALTER TABLE `sly05_wv24_cache` ENABLE KEYS */;

DROP TABLE IF EXISTS `sly05_wv24_route_cache`;
CREATE TABLE `sly05_wv24_route_cache` (
  `namespace` varchar(32) NOT NULL,
  `key` varchar(32) NOT NULL,
  `article_id` int(10) unsigned NOT NULL,
  `clang` smallint(4) unsigned NOT NULL,
  `path` varchar(32) NOT NULL,
  `url` varchar(2024) NOT NULL,
  `hash` int(10) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `params` varchar(4096) NOT NULL DEFAULT '',
  PRIMARY KEY (`namespace`,`key`),
  KEY `path` (`path`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `sly05_wv2_meta`;
CREATE TABLE `sly05_wv2_meta` (
  `object_id` int(10) unsigned NOT NULL,
  `clang` int(10) unsigned NOT NULL,
  `metainfo` varchar(64) NOT NULL,
  `meta_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`object_id`,`clang`,`metainfo`,`meta_type`),
  KEY `meta_type` (`meta_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `sly05_wv2_meta` DISABLE KEYS */;
INSERT INTO `sly05_wv2_meta` VALUES (1,1,'page',0,''),(2,1,'page',0,''),(3,1,'page',0,''),(4,1,'page',0,''),(5,1,'page',0,''),(6,1,'page',0,''),(7,1,'page',0,''),(8,1,'page',0,'');
/*!40000 ALTER TABLE `sly05_wv2_meta` ENABLE KEYS */;

DROP TABLE IF EXISTS `sly05_wv8_values`;
CREATE TABLE `sly05_wv8_values` (
  `namespace` varchar(96) NOT NULL,
  `name` varchar(96) NOT NULL,
  `values` text NOT NULL,
  PRIMARY KEY (`namespace`,`name`),
  KEY `namespace` (`namespace`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40000 ALTER TABLE `sly05_wv8_values` DISABLE KEYS */;
INSERT INTO `sly05_wv8_values` VALUES ('project','imprint','{\"1\":\"8\"}'),('project','about','{\"1\":\"7\"}'),('project','contact','{\"1\":\"6\"}'),('realurl2','use_lowercase','{\"1\":1}'),('realurl2','cleanup_names','{\"1\":1}'),('realurl2','languages','{\"1\":\"de\"}');
/*!40000 ALTER TABLE `sly05_wv8_values` ENABLE KEYS */;

