<?php $addons = array (
  0 => 'developer_utils',
  1 => 'global_settings',
  2 => 'image_resize',
  3 => 'import_export',
  4 => 'metainfo',
  5 => 'realurl2',
  6 => 'wymeditor',
);