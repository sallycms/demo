-- Sally Database Dump Version 0.6
-- Prefix sly_

SET @OLD_CHARACTER_SET_CLIENT = @@CHARACTER_SET_CLIENT;
SET @OLD_CHARACTER_SET_RESULTS = @@CHARACTER_SET_RESULTS;
SET @OLD_COLLATION_CONNECTION = @@COLLATION_CONNECTION;
SET NAMES utf8;
SET @OLD_TIME_ZONE = @@TIME_ZONE;
SET TIME_ZONE = '+00:00';
SET @OLD_UNIQUE_CHECKS = @@UNIQUE_CHECKS, UNIQUE_CHECKS = 0;
SET @OLD_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS = 0;
SET @OLD_SQL_MODE = @@SQL_MODE, SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET @OLD_SQL_NOTES = @@SQL_NOTES, SQL_NOTES = 0;

DROP TABLE IF EXISTS `sly_article`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_article` (
  `id` int(11) NOT NULL,
  `re_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `catname` varchar(255) NOT NULL,
  `catpos` int(11) NOT NULL,
  `attributes` text NOT NULL,
  `startpage` tinyint(1) NOT NULL,
  `pos` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `type` varchar(64) NOT NULL,
  `clang` int(11) NOT NULL,
  `createdate` int(11) NOT NULL,
  `updatedate` int(11) NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL DEFAULT '0',
  `wv24_fragment` varchar(64) NOT NULL,
  `wv24_skip` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`clang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_article` DISABLE KEYS;
INSERT INTO `sly_article` VALUES (1,0,'Was Sally für Sie tun kann','Was Sally für Sie tun kann',1,'',1,1,'|',1,'default',1,1312475175,1335714174,'admin','admin',0,'',0),(2,0,'Wie Sally für Sie arbeitet','Wie Sally für Sie arbeitet',2,'',1,1,'|',1,'default',1,1312475181,1327727661,'admin','admin',0,'',0),(3,0,'Was Sally einfach besser macht','Was Sally einfach besser macht',3,'',1,1,'|',1,'default',1,1312475188,1312475294,'admin','admin',0,'',0),(4,0,'Warum unsere Sally?','Warum unsere Sally?',4,'',1,1,'|',1,'default',1,1312475193,1312475297,'admin','admin',0,'',0),(5,0,'Antwort auf Ihre Fragen','Antwort auf Ihre Fragen',5,'',1,1,'|',1,'default',1,1312475199,1312475301,'admin','admin',0,'',0),(6,0,'Kontakt','',0,'',0,1,'|',1,'default',1,1312475207,1327728116,'admin','admin',0,'',0),(7,0,'Über Sally','',0,'',0,2,'|',1,'default',1,1312475211,1312475309,'admin','admin',0,'',0),(8,0,'Impressum','',0,'',0,3,'|',1,'default',1,1312475220,1312475311,'admin','admin',0,'',0);
ALTER TABLE `sly_article` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_article_slice`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_article_slice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clang` int(11) NOT NULL,
  `slot` varchar(64) NOT NULL,
  `pos` int(5) NOT NULL,
  `slice_id` bigint(20) NOT NULL DEFAULT '0',
  `article_id` int(11) NOT NULL,
  `createdate` int(11) NOT NULL,
  `updatedate` int(11) NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `find_article` (`article_id`,`clang`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_article_slice` DISABLE KEYS;
INSERT INTO `sly_article_slice` VALUES (1,1,'main',0,1,1,1312475380,1327727209,'admin','admin',0),(2,1,'main',0,2,2,1312476040,1327727661,'admin','admin',0);
ALTER TABLE `sly_article_slice` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_clang`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_clang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `revision` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_clang` DISABLE KEYS;
INSERT INTO `sly_clang` VALUES (1,'deutsch','de_DE',0);
ALTER TABLE `sly_clang` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_file`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `re_file_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `attributes` text,
  `filetype` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `originalname` varchar(255) DEFAULT NULL,
  `filesize` varchar(255) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `createdate` int(11) NOT NULL,
  `updatedate` int(11) NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `filename` (`filename`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_file` DISABLE KEYS;
INSERT INTO `sly_file` VALUES (1,0,0,NULL,'image/jpeg','fish.jpg','fish.jpg','95731',500,375,'Triggerfish',1312476017,1312476017,'admin','admin',0),(2,0,0,NULL,'image/jpeg','fish2.jpg','fish2.jpg','110850',500,375,'The unknown Fish',1312476027,1312476027,'admin','admin',0);
ALTER TABLE `sly_file` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_file_category`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_file_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `re_id` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `attributes` text,
  `createdate` int(11) NOT NULL,
  `updatedate` int(11) NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_mercurial_repository`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_mercurial_repository` (
  `repository_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `directory` varchar(128) NOT NULL,
  PRIMARY KEY (`repository_id`),
  KEY `repository_id` (`repository_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_pac_role_includes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_role_includes` (
  `role_id` bigint(20) unsigned NOT NULL,
  `included_role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`included_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Role Includes Map';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_role_includes` DISABLE KEYS;
INSERT INTO `sly_pac_role_includes` VALUES (4,3);
ALTER TABLE `sly_pac_role_includes` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_pac_roles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='Roles';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_roles` DISABLE KEYS;
INSERT INTO `sly_pac_roles` VALUES (3,'Redakteur'),(4,'Shop-Redakteur');
ALTER TABLE `sly_pac_roles` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_pac_roles_destinations_values`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_roles_destinations_values` (
  `destination` varchar(96) NOT NULL,
  `token` varchar(96) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`token`,`role_id`,`value`,`destination`),
  KEY `finder` (`destination`,`token`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Permission Values';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_roles_destinations_values` DISABLE KEYS;
INSERT INTO `sly_pac_roles_destinations_values` VALUES ('language','access',4,'1'),('varisale_config','general',4,'1'),('varisale','structure',4,'1');
ALTER TABLE `sly_pac_roles_destinations_values` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_pac_users_roles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_users_roles` (
  `user_id` varchar(96) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='User Role Map';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_users_roles` DISABLE KEYS;
INSERT INTO `sly_pac_users_roles` VALUES ('1',3),('1',4),('3',3),('3',4);
ALTER TABLE `sly_pac_users_roles` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_registry`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_registry` (
  `name` varchar(255) NOT NULL,
  `value` mediumtext,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_slice`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_slice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `module` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_slice` DISABLE KEYS;
INSERT INTO `sly_slice` VALUES (1,'wymeditor'),(2,'image');
ALTER TABLE `sly_slice` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_slice_value`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_slice_value` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `slice_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `finder` varchar(50) NOT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `slice_id` (`slice_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_slice_value` DISABLE KEYS;
INSERT INTO `sly_slice_value` VALUES (3,1,'','html','\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/p><p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. <\\/p><p>Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. <\\/p><p>Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. <\\/p><p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis. &#160;<\\/p>\"'),(4,2,'','image','\"fish2.jpg\"');
ALTER TABLE `sly_slice_value` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv13_attribute_versions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_attribute_versions` (
  `name` varchar(64) NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `properties` blob NOT NULL,
  PRIMARY KEY (`name`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_billingmethod_country`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_billingmethod_country` (
  `billing_id` smallint(5) unsigned NOT NULL,
  `country_id` tinyint(3) unsigned NOT NULL,
  `active` tinyint(1) unsigned NOT NULL,
  `charge` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`billing_id`,`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv13_billingmethod_country` DISABLE KEYS;
INSERT INTO `sly_wv13_billingmethod_country` VALUES (1,1,0,'0.000000EUR');
ALTER TABLE `sly_wv13_billingmethod_country` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv13_billingmethod_versions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_billingmethod_versions` (
  `id` smallint(5) unsigned NOT NULL,
  `clang` smallint(5) unsigned NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `title` varchar(200) NOT NULL,
  `charges` text NOT NULL,
  PRIMARY KEY (`id`,`clang`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_billingmethods`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_billingmethods` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id` smallint(5) unsigned NOT NULL,
  `clang` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `title` varchar(200) NOT NULL,
  `version_ref` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `resolve` (`id`,`clang`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv13_billingmethods` DISABLE KEYS;
INSERT INTO `sly_wv13_billingmethods` VALUES (1,1,1,'vorauskasse','Vorauskasse',NULL),(2,1,2,'vorauskasse','Vorauskasse',NULL);
ALTER TABLE `sly_wv13_billingmethods` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv13_cart_data`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_cart_data` (
  `user_id` int(10) unsigned NOT NULL,
  `key` varchar(32) NOT NULL,
  `data` blob,
  PRIMARY KEY (`user_id`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_cart_item_values`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_cart_item_values` (
  `user_id` int(10) unsigned NOT NULL,
  `item_id` smallint(5) unsigned NOT NULL,
  `attribute` varchar(64) NOT NULL,
  `attribute_version` int(10) unsigned NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`user_id`,`item_id`,`attribute`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_cart_items`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_cart_items` (
  `user_id` int(10) unsigned NOT NULL,
  `product_pid` int(10) unsigned NOT NULL,
  `item_id` smallint(5) unsigned NOT NULL,
  `attribute_hash` int(10) unsigned NOT NULL,
  `quantity` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`product_pid`,`attribute_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_categories` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL,
  `parent_id` mediumint(8) unsigned NOT NULL,
  `clang` smallint(5) unsigned NOT NULL,
  `title` varchar(200) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `position` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `id` (`id`),
  KEY `parent` (`parent_id`),
  KEY `position` (`position`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv13_categories` DISABLE KEYS;
INSERT INTO `sly_wv13_categories` VALUES (1,0,0,1,'(Start)',1,1),(2,0,0,2,'(Start)',1,1),(4,1,0,1,'Bar!',1,1),(5,1,0,2,'foo',0,1),(7,2,1,1,'Foo',0,1),(8,2,1,2,'Foo',0,1);
ALTER TABLE `sly_wv13_categories` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv13_countries`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_countries` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id` tinyint(3) unsigned NOT NULL,
  `alpha_2` char(2) NOT NULL DEFAULT '',
  `full_name` varchar(200) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `clang` smallint(5) unsigned NOT NULL,
  `version_ref` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `resolve` (`id`,`clang`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv13_countries` DISABLE KEYS;
INSERT INTO `sly_wv13_countries` VALUES (1,1,'DE','Deutschland',1,1,NULL),(2,1,'DE','Germany',1,2,NULL);
ALTER TABLE `sly_wv13_countries` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv13_country_versions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_country_versions` (
  `id` int(10) unsigned NOT NULL,
  `clang` smallint(5) unsigned NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `alpha_2` char(2) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`,`clang`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_currencies`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_currencies` (
  `symbol` char(3) NOT NULL DEFAULT '',
  `sign` varchar(3) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL,
  `ratio` double unsigned NOT NULL,
  PRIMARY KEY (`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv13_currencies` DISABLE KEYS;
INSERT INTO `sly_wv13_currencies` VALUES ('AUD','$','Australischer Dollar',1.2367000000),('BGN','лв','Lew',1.9558000000),('BRL','R$','Real',2.2830000000),('CAD','$','Kanadischer Dollar',1.3114000000),('CHF','SFr','Schweizer Franken',1.2075000000),('CNY','¥','Yuan',8.1713000000),('CZK','Kč','Tschechische Krone',25.3710000000),('DKK','dkr','Dänische Krone',7.4343000000),('EEK','kr','Estnische Krone',15.6466000000),('GBP','£','Pfund Sterling',0.8320500000),('HKD','$','Hongkong-Dollar',10.0443000000),('HRK','kn','Kuna',7.5728000000),('HUF','Ft','ForINT',298.3800000000),('IDR','Rp','Rupiah',11507.6600000000),('INR','iR','Indische Rupie',65.0270000000),('JPY','¥','Yen',101.0200000000),('KRW','₩','Südkoreanischer Won',1461.5900000000),('LTL','Lt','Litas',3.4528000000),('LVL','Ls','Lats',0.6978000000),('MXN','$','Mexikanischer Peso',17.0297000000),('MYR','RM','Ringgit',3.9903000000),('NOK','kr','Norwegische Krone',7.6825000000),('NZD','$','Neuseeländischer Dollar',1.6064000000),('PHP','₱','Philippinischer Peso',55.8250000000),('PLN','zł','Zloty',4.2966000000),('RON','L','Rumänischer Leu',4.3492000000),('RUB','руб','Russischer Rubel',39.7886000000),('SEK','kr','Schwedische Krone',8.8506000000),('SGD','$','Singapur-Dollar',1.6447000000),('THB','฿','Baht',40.8970000000),('TRY','TL','Türkische Lira',2.3660000000),('USD','$','US-Dollar',1.2942000000),('ZAR','R','Rand',10.4134000000);
ALTER TABLE `sly_wv13_currencies` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv13_currency_versions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_currency_versions` (
  `version` int(10) unsigned NOT NULL,
  `ratios` text NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_deliverymethod_country`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_deliverymethod_country` (
  `delivery_id` smallint(5) unsigned NOT NULL,
  `country_id` tinyint(3) unsigned NOT NULL,
  `active` tinyint(1) unsigned NOT NULL,
  `charge` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`delivery_id`,`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv13_deliverymethod_country` DISABLE KEYS;
INSERT INTO `sly_wv13_deliverymethod_country` VALUES (1,1,0,'0.000000EUR');
ALTER TABLE `sly_wv13_deliverymethod_country` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv13_deliverymethod_versions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_deliverymethod_versions` (
  `id` smallint(5) unsigned NOT NULL,
  `clang` smallint(5) unsigned NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `title` varchar(200) NOT NULL,
  `charges` text NOT NULL,
  PRIMARY KEY (`id`,`clang`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_deliverymethods`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_deliverymethods` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id` smallint(5) unsigned NOT NULL,
  `clang` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `title` varchar(200) NOT NULL,
  `version_ref` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `resolve` (`id`,`clang`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv13_deliverymethods` DISABLE KEYS;
INSERT INTO `sly_wv13_deliverymethods` VALUES (1,1,1,'paket','Postpaket',NULL),(2,1,2,'paket','Postpaket',NULL);
ALTER TABLE `sly_wv13_deliverymethods` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv13_order_data`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_order_data` (
  `order_id` int(10) unsigned NOT NULL,
  `key` varchar(32) NOT NULL,
  `data` blob,
  PRIMARY KEY (`order_id`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_order_histories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_order_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `changed` datetime NOT NULL,
  `eventtext` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_order_item_values`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_order_item_values` (
  `order_id` int(10) unsigned NOT NULL,
  `item_id` smallint(5) unsigned NOT NULL,
  `attribute` varchar(64) NOT NULL,
  `attribute_version` int(10) unsigned NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`order_id`,`item_id`,`attribute`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_order_items`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_order_items` (
  `order_id` int(10) unsigned NOT NULL,
  `item_id` smallint(5) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `product_variant` smallint(5) unsigned NOT NULL,
  `product_version` int(10) unsigned NOT NULL,
  `tax_version` int(10) unsigned NOT NULL,
  `quantity` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`order_id`,`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_orders`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ordered` datetime NOT NULL,
  `clang` smallint(5) unsigned NOT NULL,
  `billing_method` smallint(6) NOT NULL,
  `delivery_method` smallint(6) NOT NULL,
  `billing_version` int(10) unsigned NOT NULL,
  `delivery_version` int(10) unsigned NOT NULL,
  `currencies_version` int(10) unsigned NOT NULL,
  `total` decimal(14,3) NOT NULL,
  `status` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_product_value_versions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_product_value_versions` (
  `product_pid` int(10) unsigned NOT NULL,
  `attribute` varchar(64) NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`version`,`product_pid`,`attribute`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_product_values`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_product_values` (
  `product_pid` int(10) unsigned NOT NULL,
  `attribute` varchar(64) NOT NULL,
  `version_ref` int(10) unsigned DEFAULT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`product_pid`,`attribute`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv13_product_values` DISABLE KEYS;
INSERT INTO `sly_wv13_product_values` VALUES (7,'price',NULL,'0.000000EUR'),(7,'taxrate',NULL,'1'),(7,'test',NULL,'1'),(8,'price',NULL,'0.000000EUR'),(8,'taxrate',NULL,'1'),(8,'test',NULL,'1'),(10,'price',NULL,'13245.560000EUR'),(10,'taxrate',NULL,'1'),(10,'test',NULL,'1'),(11,'price',NULL,'13245.560000EUR'),(11,'taxrate',NULL,'1'),(11,'test',NULL,'1');
ALTER TABLE `sly_wv13_product_values` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv13_product_versions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_product_versions` (
  `id` int(10) unsigned NOT NULL,
  `variant_id` smallint(5) unsigned NOT NULL,
  `clang` smallint(5) unsigned NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `pid` int(10) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `value_versions` text NOT NULL,
  PRIMARY KEY (`id`,`variant_id`,`clang`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_products`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_products` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id` int(10) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `clang` smallint(5) unsigned NOT NULL,
  `position` int(10) unsigned NOT NULL,
  `category_id` mediumint(8) unsigned NOT NULL,
  `variant_id` smallint(5) unsigned NOT NULL,
  `product_type` varchar(64) NOT NULL,
  `links` varchar(128) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `version_ref` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `resolve` (`id`,`clang`,`variant_id`),
  KEY `position` (`position`),
  KEY `category_id` (`category_id`),
  KEY `product_type` (`product_type`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv13_products` DISABLE KEYS;
INSERT INTO `sly_wv13_products` VALUES (7,1,'Test',1,2,1,0,'default','',1,NULL),(8,1,'TEst',2,1,1,0,'default','',0,NULL),(10,2,'Test 2',1,3,1,0,'default','',1,NULL),(11,2,'Test 2',2,2,1,0,'default','|',0,NULL),(13,3,'test',1,1,1,0,'foo','',1,NULL),(14,3,'test',2,3,1,0,'foo','',0,NULL);
ALTER TABLE `sly_wv13_products` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv13_taxrate_country`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_taxrate_country` (
  `tax_id` smallint(5) unsigned NOT NULL,
  `country_id` tinyint(3) unsigned NOT NULL,
  `charge` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_id`,`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv13_taxrate_country` DISABLE KEYS;
INSERT INTO `sly_wv13_taxrate_country` VALUES (1,1,'19.00%');
ALTER TABLE `sly_wv13_taxrate_country` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv13_taxrate_versions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_taxrate_versions` (
  `tax_id` smallint(5) unsigned NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `charges` text NOT NULL,
  PRIMARY KEY (`version`,`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv13_taxrates`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv13_taxrates` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `version_ref` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv13_taxrates` DISABLE KEYS;
INSERT INTO `sly_wv13_taxrates` VALUES (1,'Umstazsteuer',NULL);
ALTER TABLE `sly_wv13_taxrates` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv16_groups`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv16_groups` (
  `name` varchar(96) NOT NULL,
  `title` varchar(200) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv16_user_groups`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv16_user_groups` (
  `user_id` smallint(5) unsigned NOT NULL,
  `group` varchar(96) NOT NULL,
  PRIMARY KEY (`user_id`,`group`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv16_user_values`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv16_user_values` (
  `user_id` int(10) unsigned NOT NULL,
  `attribute` varchar(96) NOT NULL,
  `set_id` smallint(5) NOT NULL DEFAULT '1',
  `value` text,
  PRIMARY KEY (`user_id`,`attribute`,`set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv16_users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv16_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `registered` datetime NOT NULL,
  `type` varchar(96) NOT NULL DEFAULT 'default',
  `deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `activated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `confirmed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `was_activated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `confirmation_code` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv24_cache`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv24_cache` (
  `article_id` int(10) unsigned NOT NULL,
  `clang` smallint(4) unsigned NOT NULL,
  `path` varchar(32) NOT NULL,
  `url` varchar(2024) NOT NULL,
  `hash` int(10) unsigned NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`article_id`,`clang`),
  KEY `path` (`path`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv24_route_cache`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv24_route_cache` (
  `namespace` varchar(32) NOT NULL,
  `key` varchar(32) NOT NULL,
  `article_id` int(10) unsigned NOT NULL,
  `clang` smallint(4) unsigned NOT NULL,
  `path` varchar(32) NOT NULL,
  `url` varchar(2024) NOT NULL,
  `hash` int(10) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `params` varchar(4096) NOT NULL DEFAULT '',
  PRIMARY KEY (`namespace`,`key`),
  KEY `path` (`path`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv24_urls`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv24_urls` (
  `namespace` varchar(32) NOT NULL,
  `ident` varchar(32) NOT NULL,
  `article_id` int(10) unsigned NOT NULL,
  `clang` smallint(4) unsigned NOT NULL,
  `path` varchar(128) NOT NULL,
  `url` varchar(2024) NOT NULL,
  `created` datetime NOT NULL,
  `params` varchar(4096) NOT NULL DEFAULT '',
  PRIMARY KEY (`namespace`,`ident`),
  KEY `path` (`path`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv24_urls` DISABLE KEYS;
INSERT INTO `sly_wv24_urls` VALUES ('sally.article','1_1',1,1,'|','http://sally/releases/sally-v0.6.4-starterkit/sally/','2012-04-29 17:42:12',''),('sally.article','2_1',2,1,'|','http://sally/releases/sally-v0.6.4-starterkit/sally/wie-sally-fuer-sie-arbeitet/','2012-04-29 17:42:12',''),('sally.article','3_1',3,1,'|','http://sally/releases/sally-v0.6.4-starterkit/sally/was-sally-einfach-besser-macht/','2012-04-29 17:42:12',''),('sally.article','4_1',4,1,'|','http://sally/releases/sally-v0.6.4-starterkit/sally/warum-unsere-sally/','2012-04-29 17:42:12',''),('sally.article','5_1',5,1,'|','http://sally/releases/sally-v0.6.4-starterkit/sally/antwort-auf-ihre-fragen/','2012-04-29 17:42:12',''),('sally.article','6_1',6,1,'|','http://sally/releases/sally-v0.6.4-starterkit/sally/kontakt.html','2012-04-29 17:42:12',''),('sally.article','7_1',7,1,'|','http://sally/releases/sally-v0.6.4-starterkit/sally/ueber-sally.html','2012-04-29 17:42:12',''),('sally.article','8_1',8,1,'|','http://sally/releases/sally-v0.6.4-starterkit/sally/impressum.html','2012-04-29 17:42:12','');
ALTER TABLE `sly_wv24_urls` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv2_meta`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv2_meta` (
  `object_id` int(10) unsigned NOT NULL,
  `clang` int(10) unsigned NOT NULL,
  `metainfo` varchar(64) NOT NULL,
  `meta_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`object_id`,`clang`,`metainfo`,`meta_type`),
  KEY `meta_type` (`meta_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv2_meta` DISABLE KEYS;
INSERT INTO `sly_wv2_meta` VALUES (1,1,'page',0,''),(2,1,'page',0,''),(3,1,'page',0,''),(4,1,'page',0,''),(5,1,'page',0,''),(6,1,'page',0,''),(7,1,'page',0,''),(8,1,'page',0,'');
ALTER TABLE `sly_wv2_meta` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv32_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv32_categories` (
  `id` int(8) unsigned NOT NULL,
  `clang` int(3) unsigned NOT NULL,
  `label` varchar(255) NOT NULL,
  PRIMARY KEY (`id`,`clang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv32_categories` DISABLE KEYS;
INSERT INTO `sly_wv32_categories` VALUES (1,1,'dfsdf'),(2,1,'asd');
ALTER TABLE `sly_wv32_categories` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv32_linkbacks_in`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv32_linkbacks_in` (
  `article_id` int(8) unsigned NOT NULL,
  `url` varchar(255) NOT NULL,
  `blog_name` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `excerpt` varchar(255) NOT NULL DEFAULT '',
  `type` set('trackback','pingback') NOT NULL,
  `received` datetime NOT NULL,
  PRIMARY KEY (`article_id`,`url`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv32_linkbacks_out`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv32_linkbacks_out` (
  `article_id` int(8) unsigned NOT NULL,
  `url` varchar(255) NOT NULL,
  `type` set('trackback','pingback') NOT NULL,
  `sent` datetime NOT NULL,
  PRIMARY KEY (`article_id`,`url`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_wv8_values`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv8_values` (
  `namespace` varchar(96) NOT NULL,
  `name` varchar(96) NOT NULL,
  `values` text NOT NULL,
  PRIMARY KEY (`namespace`,`name`),
  KEY `namespace` (`namespace`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv8_values` DISABLE KEYS;
INSERT INTO `sly_wv8_values` VALUES ('project','about','{\"1\":\"7\"}'),('project','contact','{\"1\":\"6\"}'),('project','imprint','{\"1\":\"8\"}'),('realurl2','cleanup','{\"1\":1}'),('realurl2','cleanup_names','{\"1\":0}'),('realurl2','languages','{\"1\":\"de\"}'),('realurl2','lowercase','{\"1\":1}'),('realurl2','use_lowercase','{\"1\":0}'),('userworkflows.articles','recovery','{\"1\":null}'),('userworkflows.articles','validation','{\"1\":null}'),('userworkflows.mail','from_email','{\"1\":null}'),('userworkflows.mail','from_name','{\"1\":null}'),('userworkflows.mail.activation','body','{\"1\":null}'),('userworkflows.mail.activation','subject','{\"1\":null}'),('userworkflows.mail.activation','to','{\"1\":null}'),('userworkflows.mail.confirmation','body','{\"1\":null}'),('userworkflows.mail.confirmation','subject','{\"1\":null}'),('userworkflows.mail.confirmation','to','{\"1\":null}'),('userworkflows.mail.recovery','body','{\"1\":null}'),('userworkflows.mail.recovery','subject','{\"1\":null}'),('userworkflows.mail.recovery','to','{\"1\":null}'),('userworkflows.mail.recoveryrequest','body','{\"1\":null}'),('userworkflows.mail.recoveryrequest','subject','{\"1\":null}'),('userworkflows.mail.recoveryrequest','to','{\"1\":null}'),('userworkflows.mail.report','body','{\"1\":null}'),('userworkflows.mail.report','subject','{\"1\":null}'),('userworkflows.mail.report','to','{\"1\":null}');
ALTER TABLE `sly_wv8_values` ENABLE KEYS;

SET TIME_ZONE = @OLD_TIME_ZONE;
SET SQL_MODE = @OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS = @OLD_UNIQUE_CHECKS;
SET CHARACTER_SET_CLIENT = @OLD_CHARACTER_SET_CLIENT;
SET CHARACTER_SET_RESULTS = @OLD_CHARACTER_SET_RESULTS;
SET COLLATION_CONNECTION = @OLD_COLLATION_CONNECTION;
SET SQL_NOTES = @OLD_SQL_NOTES;
