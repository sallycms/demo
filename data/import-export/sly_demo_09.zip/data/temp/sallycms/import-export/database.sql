-- Sally Database Dump Version 0.9.*
-- Prefix sly_

SET @OLD_CHARACTER_SET_CLIENT = @@CHARACTER_SET_CLIENT;
SET @OLD_CHARACTER_SET_RESULTS = @@CHARACTER_SET_RESULTS;
SET @OLD_COLLATION_CONNECTION = @@COLLATION_CONNECTION;
SET NAMES utf8;
SET @OLD_TIME_ZONE = @@TIME_ZONE;
SET TIME_ZONE = '+00:00';
SET @OLD_UNIQUE_CHECKS = @@UNIQUE_CHECKS, UNIQUE_CHECKS = 0;
SET @OLD_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS = 0;
SET @OLD_SQL_MODE = @@SQL_MODE, SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET @OLD_SQL_NOTES = @@SQL_NOTES, SQL_NOTES = 0;

DROP TABLE IF EXISTS `sly_article`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_article` (
  `id` int(10) unsigned NOT NULL,
  `clang` int(10) unsigned NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  `latest` tinyint(1) NOT NULL DEFAULT '0',
  `online` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `re_id` int(10) unsigned NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pos` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `catpos` int(10) unsigned NOT NULL,
  `catname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `startpage` tinyint(1) NOT NULL DEFAULT '0',
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `updateuser` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `attributes` longtext COLLATE utf8_unicode_ci NOT NULL,
  `wv24_fragment` varchar(256) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `wv24_skip` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`clang`,`revision`),
  KEY `parents` (`re_id`),
  KEY `types` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_article` DISABLE KEYS;
INSERT INTO `sly_article` VALUES (1,1,0,0,0,0,'default',0,'|',0,'Was Sally für Sie tun kann',1,'Was Sally für Sie tun kann',1,'2013-01-27 00:46:16','2013-01-27 01:21:01','admin','test','','',0),(1,1,1,0,0,0,'default',0,'|',0,'Was Sally für Sie tun kann',1,'Was Sally für Sie tun kann',1,'2014-03-18 17:34:29','2014-03-18 17:34:29','admin','admin','','',0),(1,1,2,0,0,0,'default',0,'|',0,'Was Sally für Sie tun kann',1,'Was Sally für Sie tun kann',1,'2014-03-18 17:45:12','2014-03-18 17:45:12','admin','admin','','',0),(1,1,3,0,0,0,'default',0,'|',0,'Was Sally für Sie tun kann',1,'Was Sally für Sie tun kann',1,'2014-03-18 17:48:07','2014-03-18 17:48:07','admin','admin','','',0),(1,1,4,1,1,0,'default',0,'|',0,'Was Sally für Sie tun kann',1,'Was Sally für Sie tun kann',1,'2014-03-18 17:54:08','2014-03-18 17:54:08','admin','admin','','',0),(2,1,0,1,1,0,'default',0,'|',0,'Wie Sally für Sie arbeitet',2,'Wie Sally für Sie arbeitet',1,'2013-01-27 00:46:22','2013-01-27 01:18:37','admin','admin','','',0),(3,1,0,0,0,0,'default',0,'|',0,'Was Sally einfach besser macht',3,'Was Sally einfach besser macht',1,'2013-01-27 00:46:28','2013-01-27 01:11:43','admin','admin','','',0),(3,1,1,0,0,0,'default',0,'|',0,'Was Sally einfach besser macht',3,'Was Sally einfach besser macht',1,'2014-03-18 17:19:27','2014-03-18 17:19:27','admin','admin','','',0),(3,1,2,1,1,0,'default',0,'|',0,'Was Sally einfach besser macht',3,'Was Sally einfach besser macht',1,'2014-03-18 17:20:08','2014-03-18 17:20:08','admin','admin','','',0),(4,1,0,1,1,0,'default',0,'|',0,'Warum unsere Sally?',4,'Warum unsere Sally?',1,'2013-01-27 00:46:33','2013-01-27 00:47:59','admin','admin','','',0),(5,1,0,1,1,0,'default',0,'|',0,'Antwort auf Ihre Fragen',5,'Antwort auf Ihre Fragen',1,'2013-01-27 00:46:39','2013-01-27 00:48:03','admin','admin','','',0),(6,1,0,0,0,0,'default',0,'|',1,'Kontakt',0,'',0,'2013-01-27 00:46:43','2013-01-27 00:47:23','admin','admin','','',0),(6,1,1,0,0,0,'default',0,'|',1,'Kontakt',0,'',0,'2014-03-19 10:11:36','2014-03-19 10:11:36','admin','admin','','',0),(6,1,2,1,1,0,'default',0,'|',1,'Kontakt',0,'',0,'2014-03-19 10:42:18','2014-03-19 10:42:18','admin','admin','','',0),(7,1,0,1,1,0,'default',0,'|',2,'Über Sally',0,'',0,'2013-01-27 00:46:48','2013-01-27 00:47:26','admin','admin','','',0),(8,1,0,1,1,0,'default',0,'|',3,'Impressum',0,'',0,'2013-01-27 00:46:53','2013-01-27 00:47:42','admin','admin','','',0);
ALTER TABLE `sly_article` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_article_slice`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_article_slice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int(10) unsigned NOT NULL,
  `clang` int(10) unsigned NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  `pos` int(10) unsigned NOT NULL,
  `slot` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `slice_id` int(10) unsigned NOT NULL,
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `updateuser` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `find_article` (`article_id`,`clang`,`revision`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_article_slice` DISABLE KEYS;
INSERT INTO `sly_article_slice` VALUES (1,1,1,0,0,'main',1,'2013-01-27 01:01:40','2013-01-27 01:21:01','admin','test'),(2,3,1,0,0,'main',2,'2013-01-27 01:11:43','2013-01-27 01:11:43','admin','admin'),(3,2,1,0,0,'main',3,'2013-01-27 01:15:15','2013-01-27 01:15:15','admin','admin'),(4,2,1,0,1,'main',4,'2013-01-27 01:16:08','2013-01-27 01:16:08','admin','admin'),(5,2,1,0,2,'main',5,'2013-01-27 01:18:18','2013-01-27 01:18:37','admin','admin'),(6,2,1,0,3,'main',6,'2013-01-27 01:18:28','2013-01-27 01:18:28','admin','admin'),(7,3,1,1,0,'main',7,'2014-03-18 17:19:27','2014-03-18 17:19:27','admin','admin'),(8,3,1,2,0,'main',8,'2014-03-18 17:20:08','2014-03-18 17:20:08','admin','admin'),(9,1,1,1,0,'main',9,'2014-03-18 17:34:29','2014-03-18 17:34:29','admin','admin'),(10,1,1,2,0,'main',10,'2014-03-18 17:45:12','2014-03-18 17:45:12','admin','admin'),(11,1,1,3,0,'main',11,'2014-03-18 17:48:07','2014-03-18 17:48:07','admin','admin'),(12,1,1,4,0,'main',12,'2014-03-18 17:54:08','2014-03-18 17:54:08','admin','admin'),(13,6,1,1,0,'main',13,'2014-03-19 10:11:36','2014-03-19 10:11:36','admin','admin'),(14,6,1,2,0,'main',14,'2014-03-19 10:42:18','2014-03-19 10:42:18','admin','admin');
ALTER TABLE `sly_article_slice` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_clang`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_clang` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `locale` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_clang` DISABLE KEYS;
INSERT INTO `sly_clang` VALUES (1,'deutsch','de_DE',0);
ALTER TABLE `sly_clang` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_config`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_config` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_config` DISABLE KEYS;
INSERT INTO `sly_config` VALUES ('addons','{\"sallycms:be-search\":{\"install\":true,\"status\":true},\"sallycms:image-resize\":{\"install\":true,\"status\":true,\"default_filters\":[],\"max_cachefiles\":5,\"max_filters\":5,\"max_resizekb\":1000,\"max_resizepixel\":2000,\"jpg_quality\":75,\"upscaling_allowed\":0,\"recompress\":1,\"append_hash\":0},\"sallycms:import-export\":{\"install\":true,\"status\":true},\"webvariants:developer-utils\":{\"install\":true,\"status\":true},\"webvariants:metainfo\":{\"install\":true,\"status\":true},\"webvariants:redirect\":{\"install\":true,\"status\":true},\"webvariants:global-settings\":{\"install\":true,\"status\":true},\"webvariants:realurl2\":{\"install\":true,\"status\":true},\"mediastuttgart:ckeditor\":{\"install\":true,\"status\":true}}'),('default_article_type','\"default\"'),('default_clang_id','1'),('default_locale','\"de_de\"'),('environment','\"dev\"'),('modules','{\"data\":{\"ckeditor\":{\"input\":{\"ckeditor.input.php\":{\"filename\":\"ckeditor.input.php\",\"title\":\"Texteditor (CKEditor)\",\"mtime\":1395163213,\"params\":[]}},\"output\":{\"ckeditor.output.php\":{\"filename\":\"ckeditor.output.php\",\"title\":\"ckeditor\",\"mtime\":1395163028,\"params\":[]}}},\"image\":{\"input\":{\"image.input.php\":{\"filename\":\"image.input.php\",\"title\":\"Bild\",\"mtime\":1394723904,\"params\":[]}},\"output\":{\"image.output.php\":{\"filename\":\"image.output.php\",\"title\":\"Bild\",\"mtime\":1395215643,\"params\":[]}}}},\"last_refresh\":1395219869}'),('notfound_article_id','1'),('projectname','\"Sally Demo\"'),('start_article_id','1'),('templates','{\"data\":{\"bottom\":{\"default\":{\"bottom.php\":{\"filename\":\"bottom.php\",\"title\":\"bottom\",\"slots\":{\"default\":\"\"},\"mtime\":1394723904,\"params\":[]}}},\"standard\":{\"default\":{\"standard.php\":{\"filename\":\"standard.php\",\"title\":\"standard\",\"slots\":{\"main\":\"Hauptbereich\"},\"mtime\":1394723904,\"params\":[]}}},\"top\":{\"default\":{\"top.php\":{\"filename\":\"top.php\",\"title\":\"top\",\"slots\":{\"default\":\"\"},\"mtime\":1394723904,\"params\":[]}}},\"twocolumn\":{\"default\":{\"twocolumn.php\":{\"filename\":\"twocolumn.php\",\"title\":\"twocolumn\",\"slots\":{\"left\":\"Linke Spalte\",\"right\":\"Rechte Spalte\"},\"mtime\":1394723904,\"params\":[]}}}},\"last_refresh\":1394726145}'),('timezone','\"Europe\\/Berlin\"'),('versions','{\"package\":{\"sallycms:import-export\":\"4.x-dev\",\"webvariants:developer-utils\":\"6.x-dev\",\"webvariants:global-settings\":\"6.x-dev\",\"webvariants:realurl2\":\"5.x-dev\",\"webvariants:metainfo\":\"7.x-dev\",\"webvariants:redirect\":\"1.x-dev\",\"sallycms:image-resize\":\"4.x-dev\",\"sallycms:be-search\":\"2.x-dev\",\"mediastuttgart:ckeditor\":\"2.x-dev\"}}');
ALTER TABLE `sly_config` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_file`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `re_file_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `attributes` text COLLATE utf8_unicode_ci,
  `filetype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `originalname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filesize` int(10) unsigned NOT NULL,
  `width` int(10) unsigned NOT NULL,
  `height` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updateuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `filename` (`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_file` DISABLE KEYS;
INSERT INTO `sly_file` VALUES (1,0,0,'','image/jpeg','fish.jpg','fish.jpg',95731,500,375,'Triggerfish','2013-01-27 01:15:23','2013-01-27 01:15:42','admin','admin',0),(2,0,0,'','image/jpeg','fish2.jpg','fish2.jpg',110850,500,375,'The unknown Fish','2013-01-27 01:15:23','2013-01-27 01:16:00','admin','admin',0);
ALTER TABLE `sly_file` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_file_category`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_file_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `re_id` int(10) unsigned NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `attributes` text COLLATE utf8_unicode_ci,
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updateuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_pac_role_includes`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_role_includes` (
  `role_id` bigint(20) unsigned NOT NULL,
  `included_role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`included_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Role Includes Map';
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_pac_roles`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Roles';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_roles` DISABLE KEYS;
INSERT INTO `sly_pac_roles` VALUES (1,'Redakteur');
ALTER TABLE `sly_pac_roles` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_pac_roles_destinations_values`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_roles_destinations_values` (
  `destination` varchar(96) NOT NULL,
  `token` varchar(96) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  `value` varchar(96) NOT NULL,
  PRIMARY KEY (`token`,`role_id`,`value`,`destination`),
  KEY `finder` (`destination`,`token`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Permission Values';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_roles_destinations_values` DISABLE KEYS;
INSERT INTO `sly_pac_roles_destinations_values` VALUES ('mediacategory','access',1,'0'),('language','access',1,'1'),('module','add',1,'0'),('apps','backend',1,'1'),('global_settings','backend',1,'1'),('module','delete',1,'0'),('article','edit',1,'0'),('module','edit',1,'0'),('metainfo','edit',1,'1'),('article','editcontent',1,'0'),('article','edittype',1,'0'),('pages','globalsettings',1,'1'),('pages','mediapool',1,'1'),('article','move',1,'0'),('module','move',1,'0'),('article','publish',1,'0'),('pages','structure',1,'1'),('metainfo','view',1,'1');
ALTER TABLE `sly_pac_roles_destinations_values` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_pac_users_roles`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_users_roles` (
  `user_id` varchar(96) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='User Role Map';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_users_roles` DISABLE KEYS;
INSERT INTO `sly_pac_users_roles` VALUES ('2',1);
ALTER TABLE `sly_pac_users_roles` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_registry`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_registry` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` blob NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_registry` DISABLE KEYS;
INSERT INTO `sly_registry` VALUES ('wv-globalsettings','a:7:{s:7:\"imprint\";a:4:{s:5:\"title\";s:9:\"Impressum\";s:8:\"pagename\";s:13:\"Einstellungen\";s:8:\"datatype\";s:10:\"linkbutton\";s:5:\"group\";s:11:\"Footerlinks\";}s:5:\"about\";a:4:{s:5:\"title\";s:11:\"Über Sally\";s:8:\"pagename\";s:13:\"Einstellungen\";s:8:\"datatype\";s:10:\"linkbutton\";s:5:\"group\";s:11:\"Footerlinks\";}s:7:\"contact\";a:4:{s:5:\"title\";s:7:\"Kontakt\";s:8:\"pagename\";s:13:\"Einstellungen\";s:8:\"datatype\";s:10:\"linkbutton\";s:5:\"group\";s:11:\"Footerlinks\";}s:25:\"realurl2.default_fragment\";a:8:{s:5:\"title\";s:17:\"Standard-Fragment\";s:8:\"datatype\";s:10:\"stringline\";s:6:\"params\";a:1:{s:9:\"maxlength\";i:128;}s:8:\"pagename\";s:8:\"realURL2\";s:5:\"group\";s:11:\"Allgemeines\";s:8:\"helptext\";s:86:\"Die Standard-Domain als URL-Fragment mit evtl. Verzeichnis (//example.com/slywebsite).\";s:5:\"local\";b:1;s:12:\"multilingual\";b:1;}s:18:\"realurl2.lowercase\";a:6:{s:5:\"title\";s:22:\"Groß-/Kleinschreibung\";s:8:\"datatype\";s:7:\"boolean\";s:6:\"params\";a:1:{s:11:\"description\";s:46:\"URLs sollen in Kleinschreibung erzeugt werden.\";}s:8:\"pagename\";s:8:\"realURL2\";s:5:\"group\";s:11:\"Allgemeines\";s:12:\"multilingual\";b:1;}s:16:\"realurl2.cleanup\";a:6:{s:5:\"title\";s:15:\"URLs bereinigen\";s:8:\"datatype\";s:7:\"boolean\";s:6:\"params\";a:1:{s:11:\"description\";s:68:\"Sonderzeichen in Artikel- und Kategorienamen sollen entfernt werden.\";}s:8:\"pagename\";s:8:\"realURL2\";s:5:\"group\";s:11:\"Allgemeines\";s:12:\"multilingual\";b:1;}s:21:\"realurl2.unique_types\";a:7:{s:5:\"title\";s:23:\"Eindeutigkeit erzwingen\";s:8:\"datatype\";s:21:\"realurl2_articletypes\";s:6:\"params\";a:1:{s:3:\"min\";i:0;}s:8:\"pagename\";s:8:\"realURL2\";s:5:\"group\";s:24:\"Erweiterte Einstellungen\";s:12:\"multilingual\";b:0;s:8:\"helptext\";s:418:\"Alle Artikel, die die hier ausgewählten Artikeltypen verwenden, erhalten garantiert eindeutige URLs (indem die Artikel-ID in die URL eingefügt wird). Dies ist nützlich, wenn gleichnamige Artikel in einer Kategorie liegen sollen (z.B. zwei gleich benannte Pressemitteilungen). Diese Option sollte nur für ausgewählte Artikeltypen aktiviert werden, um für die meisten Artikel saubere (\"SEO\") URLs sicherzustellen.\n\";}}'),('wv-metainfo-articles','a:2:{s:4:\"page\";a:5:{s:5:\"title\";s:24:\"alternativer Seitentitel\";s:8:\"datatype\";s:10:\"stringline\";s:6:\"params\";a:1:{s:9:\"maxlength\";i:50;}s:8:\"metapage\";b:0;s:5:\"types\";a:2:{i:0;s:7:\"default\";i:1;s:9:\"twocolumn\";}}s:16:\"wv44_redirect_to\";a:5:{s:5:\"title\";s:30:\"translate:redirect_redirect_to\";s:8:\"helptext\";s:27:\"translate:redirect_helptext\";s:8:\"datatype\";s:3:\"url\";s:5:\"types\";a:1:{i:0;s:8:\"redirect\";}s:6:\"params\";a:1:{s:8:\"required\";b:1;}}}'),('wv-metainfo-categories','a:0:{}'),('wv-metainfo-media','a:0:{}'),('wv-metainfo-users','a:0:{}');
ALTER TABLE `sly_registry` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_slice`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_slice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `serialized_values` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_slice` DISABLE KEYS;
INSERT INTO `sly_slice` VALUES (1,'ckeditor','{\"html\":\"<p>Sally CMS ist ein flexibles, performantes und erweiterbares Content Management System (CMS). Sally richtet sich an professionelle Entwickler und Integratoren, die damit Webprojekte umsetzen wollen. Die Weiterentwicklung findet agil mit kurzen, schnellen Releasezyklen und dadurch schneller Fehlerbeseitigung statt. Sally f\\u00fcgt sich hervorragend in Entwicklungsumgebungen ein, in denen mehrere Entwicklung gemeinsan an einem Projekt arbeiten. Auch die modulare Architektur tr\\u00e4gt dazu bei.<\\/p><p>F\\u00fcr Redakteure ist Sally einfach und schnell zu verstehen, ohne das umfangreiche Schulungen notwendig sind. Innerhalb von einer Stunde ist man auch als Neuling in der Lage, die Inhalte seiner Website zu \\u00e4ndern und zu erg\\u00e4nzen.<\\/p><p>Sally wird unter MIT-Lizenz ver\\u00f6ffentlicht und ist dadurch problemlos f\\u00fcr kommerzielle Projekte einsetzbar.<\\/p>\"}'),(2,'ckeditor','{\"html\":\"<div><ul><li>hohe Performance&#160;<\\/li><li>niedriger System-Overhead&#160;<\\/li><li>saubere MVC-Architektur<\\/li><li>systemweites Caching mit APC\\/XCache\\/Memcache\\/eAccelerator\\/Dateisystem&#160;<\\/li><li>frei gestaltbares Frontend&#160;<\\/li><li>\\u00fcbersichtliches, erweiterbares Backend&#160;<\\/li><li>vielseitig erweiterbar durch AddOns (alle MIT-Lizenz)&#160;<\\/li><li>native Mehrsprachigkeit(Frontend\\/Backend)&#160;<\\/li><li>erweiterbares Rechtesystem&#160;<\\/li><li>klare Trennung zwischen Entwickler und Redakteur&#160;<\\/li><li>kurze Entwicklungszyklen, h\\u00e4ufige Releases&#160;<\\/li><li>MIT-Lizenz und daher problemlos kommerziell einsetzbar&#160;<\\/li><li>kompatibel mit PHP 5.2 bis 5.4<\\/li><\\/ul><\\/div>\"}'),(3,'ckeditor','{\"html\":\"<p>Lorem-Ipsum in Fischform:<\\/p>\"}'),(4,'image','{\"image\":\"fish.jpg\"}'),(5,'ckeditor','{\"html\":\"<h2>The Unknown Fish<\\/h2>\"}'),(6,'image','{\"image\":\"fish2.jpg\"}'),(7,'ckeditor','{\"ckeditor\":\"<div>\\r\\n<ul>\\r\\n\\t<li>hohe Performance&nbsp;<\\/li>\\r\\n\\t<li>niedriger System-Overhead&nbsp;<\\/li>\\r\\n\\t<li>saubere MVC-Architektur<\\/li>\\r\\n\\t<li>systemweites Caching mit APC\\/XCache\\/Memcache\\/eAccelerator\\/Dateisystem&nbsp;<\\/li>\\r\\n\\t<li>frei gestaltbares Frontend&nbsp;<\\/li>\\r\\n\\t<li>&uuml;bersichtliches, erweiterbares Backend&nbsp;<\\/li>\\r\\n\\t<li>vielseitig erweiterbar durch AddOns (alle MIT-Lizenz)&nbsp;<\\/li>\\r\\n\\t<li>native Mehrsprachigkeit(Frontend\\/Backend)&nbsp;<\\/li>\\r\\n\\t<li>erweiterbares Rechtesystem&nbsp;<\\/li>\\r\\n\\t<li>klare Trennung zwischen Entwickler und Redakteur&nbsp;<\\/li>\\r\\n\\t<li>kurze Entwicklungszyklen, h&auml;ufige Releases&nbsp;<\\/li>\\r\\n\\t<li>MIT-Lizenz und daher problemlos kommerziell einsetzbar&nbsp;<\\/li>\\r\\n\\t<li>kompatibel mit PHP 5.3&nbsp;bis 5.5<\\/li>\\r\\n<\\/ul>\\r\\n<\\/div>\\r\\n\"}'),(8,'ckeditor','{\"html\":\"<div>\\r\\n<ul>\\r\\n\\t<li>hohe Performance&nbsp;<\\/li>\\r\\n\\t<li>niedriger System-Overhead&nbsp;<\\/li>\\r\\n\\t<li>saubere MVC-Architektur<\\/li>\\r\\n\\t<li>systemweites Caching mit APC\\/XCache\\/Memcache\\/eAccelerator\\/Dateisystem&nbsp;<\\/li>\\r\\n\\t<li>frei gestaltbares Frontend&nbsp;<\\/li>\\r\\n\\t<li>&uuml;bersichtliches, erweiterbares Backend&nbsp;<\\/li>\\r\\n\\t<li>vielseitig erweiterbar durch AddOns (alle MIT-Lizenz)&nbsp;<\\/li>\\r\\n\\t<li>native Mehrsprachigkeit(Frontend\\/Backend)&nbsp;<\\/li>\\r\\n\\t<li>erweiterbares Rechtesystem&nbsp;<\\/li>\\r\\n\\t<li>klare Trennung zwischen Entwickler und Redakteur&nbsp;<\\/li>\\r\\n\\t<li>kurze Entwicklungszyklen, h&auml;ufige Releases&nbsp;<\\/li>\\r\\n\\t<li>MIT-Lizenz und daher problemlos kommerziell einsetzbar&nbsp;<\\/li>\\r\\n\\t<li>kompatibel mit PHP 5.3&nbsp;bis 5.5<\\/li>\\r\\n<\\/ul>\\r\\n<\\/div>\\r\\n\"}'),(9,'ckeditor','{\"html\":\"<p>Sally CMS ist ein flexibles, performantes und erweiterbares Content Management System (CMS). Sally richtet sich an professionelle Entwickler und Integratoren, die damit Webprojekte umsetzen wollen. Die Weiterentwicklung findet agil mit kurzen, schnellen Releasezyklen und dadurch schneller Fehlerbeseitigung statt. Sally f&uuml;gt sich hervorragend in Entwicklungsumgebungen ein, in denen mehrere Entwicklung gemeinsan an einem Projekt arbeiten. Auch die modulare Architektur tr&auml;gt dazu bei.<\\/p>\\r\\n\\r\\n<p>F&uuml;r Redakteure ist Sally einfach und schnell zu verstehen, ohne das umfangreiche Schulungen notwendig sind. Innerhalb von einer Stunde ist man auch als Neuling in der Lage, die Inhalte seiner Website zu &auml;ndern und zu erg&auml;nzen.<\\/p>\\r\\n\\r\\n<p>Sally wird unter MIT-Lizenz ver&ouml;ffentlicht und ist dadurch problemlos f&uuml;r kommerzielle Projekte einsetzbar.<\\/p>\\r\\n\\r\\n<p><img alt=\\\"Triggerfish\\\" src=\\\"mediapool\\/fish.jpg\\\" \\/><\\/p>\\r\\n\"}'),(10,'ckeditor','{\"html\":\"<p>Sally CMS ist ein flexibles, performantes und erweiterbares Content Management System (CMS). Sally richtet sich an professionelle Entwickler und Integratoren, die damit Webprojekte umsetzen wollen. Die Weiterentwicklung findet agil mit kurzen, schnellen Releasezyklen und dadurch schneller Fehlerbeseitigung statt. Sally f&uuml;gt sich hervorragend in Entwicklungsumgebungen ein, in denen mehrere Entwicklung gemeinsan an einem Projekt arbeiten. Auch die modulare Architektur tr&auml;gt dazu bei.<\\/p>\\r\\n\\r\\n<p>F&uuml;r Redakteure ist Sally einfach und schnell zu verstehen, ohne das umfangreiche Schulungen notwendig sind. Innerhalb von einer Stunde ist man auch als Neuling in der Lage, die Inhalte seiner Website zu &auml;ndern und zu erg&auml;nzen.<\\/p>\\r\\n\\r\\n<p>Sally wird unter MIT-Lizenz ver&ouml;ffentlicht und ist dadurch problemlos f&uuml;r kommerzielle Projekte einsetzbar.<\\/p>\\r\\n\\r\\n<p><img alt=\\\"Triggerfish\\\" src=\\\"..\\/mediapool\\/fish.jpg\\\" \\/><\\/p>\\r\\n\"}'),(11,'ckeditor','{\"html\":\"<p>Sally CMS ist ein flexibles, performantes und erweiterbares Content Management System (CMS). Sally richtet sich an professionelle Entwickler und Integratoren, die damit Webprojekte umsetzen wollen. Die Weiterentwicklung findet agil mit kurzen, schnellen Releasezyklen und dadurch schneller Fehlerbeseitigung statt. Sally f&uuml;gt sich hervorragend in Entwicklungsumgebungen ein, in denen mehrere Entwicklung gemeinsan an einem Projekt arbeiten. Auch die modulare Architektur tr&auml;gt dazu bei.<\\/p>\\r\\n\\r\\n<p>F&uuml;r Redakteure ist Sally einfach und schnell zu verstehen, ohne das umfangreiche Schulungen notwendig sind. Innerhalb von einer Stunde ist man auch als Neuling in der Lage, die Inhalte seiner Website zu &auml;ndern und zu erg&auml;nzen.<\\/p>\\r\\n\\r\\n<p>Sally wird unter MIT-Lizenz ver&ouml;ffentlicht und ist dadurch problemlos f&uuml;r kommerzielle Projekte einsetzbar.<\\/p>\\r\\n\\r\\n<p><img alt=\\\"Triggerfish\\\" src=\\\"mediapool\\/fish.jpg\\\" \\/><\\/p>\\r\\n\"}'),(12,'ckeditor','{\"html\":\"<p>Sally CMS ist ein flexibles, performantes und erweiterbares Content Management System (CMS). Sally richtet sich an professionelle Entwickler und Integratoren, die damit Webprojekte umsetzen wollen. Die Weiterentwicklung findet agil mit kurzen, schnellen Releasezyklen und dadurch schneller Fehlerbeseitigung statt. Sally f&uuml;gt sich hervorragend in Entwicklungsumgebungen ein, in denen mehrere Entwicklung gemeinsan an einem Projekt arbeiten. Auch die modulare Architektur tr&auml;gt dazu bei.<\\/p>\\r\\n\\r\\n<p>F&uuml;r Redakteure ist Sally einfach und schnell zu verstehen, ohne das umfangreiche Schulungen notwendig sind. Innerhalb von einer Stunde ist man auch als Neuling in der Lage, die Inhalte seiner Website zu &auml;ndern und zu erg&auml;nzen.<\\/p>\\r\\n\\r\\n<p>Sally wird unter MIT-Lizenz ver&ouml;ffentlicht und ist dadurch problemlos f&uuml;r kommerzielle Projekte einsetzbar.<\\/p>\\r\\n\"}'),(13,'ckeditor','{\"html\":\"<h2>Visit us:<\\/h2>\\r\\n\\r\\n<ul>\\r\\n\\t<li>http:\\/\\/www.sallycms.de\\/<\\/li>\\r\\n\\t<li>https:\\/\\/bitbucket.org\\/SallyCMS<\\/li>\\r\\n\\t<li>https:\\/\\/projects.webvariants.de\\/projects\\/sallycms\\/boards<\\/li>\\r\\n<\\/ul>\\r\\n\\r\\n<p>&nbsp;<\\/p>\\r\\n\\r\\n<p>&nbsp;<\\/p>\\r\\n\"}'),(14,'ckeditor','{\"html\":\"<h2>Visit us:<\\/h2>\\r\\n\\r\\n<ul>\\r\\n\\t<li><a href=\\\"http:\\/\\/www.sallycms.de\\/\\\">http:\\/\\/www.sallycms.de\\/<\\/a><\\/li>\\r\\n\\t<li><a href=\\\"https:\\/\\/bitbucket.org\\/SallyCMS\\\">https:\\/\\/bitbucket.org\\/SallyCMS<\\/a><\\/li>\\r\\n\\t<li><a href=\\\"https:\\/\\/projects.webvariants.de\\/projects\\/sallycms\\/boards\\\">https:\\/\\/projects.webvariants.de\\/projects\\/sallycms\\/boards<\\/a><\\/li>\\r\\n<\\/ul>\\r\\n\\r\\n<p>&nbsp;<\\/p>\\r\\n\\r\\n<p>&nbsp;<\\/p>\\r\\n\"}');
ALTER TABLE `sly_slice` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv2_meta`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv2_meta` (
  `object_id` int(10) unsigned NOT NULL,
  `clang` int(10) unsigned NOT NULL,
  `revision` int(10) unsigned NOT NULL,
  `metainfo` varchar(64) NOT NULL,
  `meta_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`object_id`,`clang`,`revision`,`metainfo`,`meta_type`),
  KEY `meta_type` (`meta_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv2_meta` DISABLE KEYS;
INSERT INTO `sly_wv2_meta` VALUES (1,1,0,'page',0,NULL),(1,1,1,'page',0,NULL),(1,1,2,'page',0,NULL),(1,1,3,'page',0,NULL),(1,1,4,'page',0,NULL),(2,1,0,'page',0,NULL),(3,1,0,'page',0,NULL),(3,1,1,'page',0,NULL),(3,1,2,'page',0,NULL),(4,1,0,'page',0,NULL),(5,1,0,'page',0,NULL),(6,1,0,'page',0,NULL),(6,1,1,'page',0,NULL),(6,1,2,'page',0,NULL),(7,1,0,'page',0,NULL),(8,1,0,'page',0,NULL);
ALTER TABLE `sly_wv2_meta` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv8_values`;
SET @saved_cs_client = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv8_values` (
  `namespace` varchar(96) NOT NULL,
  `name` varchar(96) NOT NULL,
  `values` text NOT NULL,
  PRIMARY KEY (`namespace`,`name`),
  KEY `namespace` (`namespace`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv8_values` DISABLE KEYS;
INSERT INTO `sly_wv8_values` VALUES ('project','about','{\"1\":\"7\"}'),('project','contact','{\"1\":\"6\"}'),('project','imprint','{\"1\":\"8\"}'),('realurl2','cleanup','{\"1\":1}'),('realurl2','lowercase','{\"1\":1}'),('realurl2','unique_types','{\"1\":\"\"}');
ALTER TABLE `sly_wv8_values` ENABLE KEYS;

SET TIME_ZONE = @OLD_TIME_ZONE;
SET SQL_MODE = @OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS = @OLD_UNIQUE_CHECKS;
SET CHARACTER_SET_CLIENT = @OLD_CHARACTER_SET_CLIENT;
SET CHARACTER_SET_RESULTS = @OLD_CHARACTER_SET_RESULTS;
SET COLLATION_CONNECTION = @OLD_COLLATION_CONNECTION;
SET SQL_NOTES = @OLD_SQL_NOTES;
