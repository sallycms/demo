-- Sally Database Dump Version 0.7.*
-- Prefix sly_

SET @OLD_CHARACTER_SET_CLIENT = @@CHARACTER_SET_CLIENT;
SET @OLD_CHARACTER_SET_RESULTS = @@CHARACTER_SET_RESULTS;
SET @OLD_COLLATION_CONNECTION = @@COLLATION_CONNECTION;
SET NAMES utf8;
SET @OLD_TIME_ZONE = @@TIME_ZONE;
SET TIME_ZONE = '+00:00';
SET @OLD_UNIQUE_CHECKS = @@UNIQUE_CHECKS, UNIQUE_CHECKS = 0;
SET @OLD_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS = 0;
SET @OLD_SQL_MODE = @@SQL_MODE, SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET @OLD_SQL_NOTES = @@SQL_NOTES, SQL_NOTES = 0;

DROP TABLE IF EXISTS `sly_article`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_article` (
  `id` int(10) unsigned NOT NULL,
  `clang` int(10) unsigned NOT NULL,
  `re_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `catname` varchar(255) NOT NULL,
  `catpos` int(10) unsigned NOT NULL,
  `attributes` text NOT NULL,
  `startpage` tinyint(1) NOT NULL,
  `pos` int(10) unsigned NOT NULL,
  `path` varchar(255) NOT NULL,
  `status` int(10) unsigned NOT NULL,
  `type` varchar(64) NOT NULL,
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  `wv24_fragment` varchar(256) NOT NULL,
  `wv24_skip` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`clang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_article` DISABLE KEYS;
INSERT INTO `sly_article` VALUES (1,1,0,'Was Sally für Sie tun kann','Was Sally für Sie tun kann',1,'',1,1,'|',1,'default','0000-00-00 00:00:00','2012-07-12 15:51:49','admin','admin',0,'',0),(2,1,0,'Wie Sally für Sie arbeitet','Wie Sally für Sie arbeitet',2,'',1,1,'|',1,'default','0000-00-00 00:00:00','2012-07-12 15:48:58','admin','admin',0,'',0),(3,1,0,'Was Sally einfach besser macht','Was Sally einfach besser macht',3,'',1,1,'|',1,'default','0000-00-00 00:00:00','0000-00-00 00:00:00','admin','admin',0,'',0),(4,1,0,'Warum unsere Sally?','Warum unsere Sally?',4,'',1,1,'|',1,'default','0000-00-00 00:00:00','0000-00-00 00:00:00','admin','admin',0,'',0),(5,1,0,'Antwort auf Ihre Fragen','Antwort auf Ihre Fragen',5,'',1,1,'|',1,'default','0000-00-00 00:00:00','0000-00-00 00:00:00','admin','admin',0,'',0),(6,1,0,'Kontakt','',0,'',0,1,'|',1,'default','0000-00-00 00:00:00','0000-00-00 00:00:00','admin','admin',0,'',0),(7,1,0,'Über Sally','',0,'',0,2,'|',1,'default','0000-00-00 00:00:00','0000-00-00 00:00:00','admin','admin',0,'',0),(8,1,0,'Impressum','',0,'',0,3,'|',1,'default','0000-00-00 00:00:00','0000-00-00 00:00:00','admin','admin',0,'',0);
ALTER TABLE `sly_article` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_article_slice`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_article_slice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `clang` int(10) unsigned NOT NULL,
  `slot` varchar(64) NOT NULL,
  `pos` int(10) unsigned NOT NULL,
  `slice_id` int(10) unsigned NOT NULL DEFAULT '0',
  `article_id` int(10) unsigned NOT NULL,
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `find_article` (`article_id`,`clang`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_article_slice` DISABLE KEYS;
INSERT INTO `sly_article_slice` VALUES (1,1,'main',0,1,1,'0000-00-00 00:00:00','2012-07-12 15:51:49','admin','admin',0),(2,1,'main',0,2,2,'0000-00-00 00:00:00','2012-07-12 15:48:58','admin','admin',0);
ALTER TABLE `sly_article_slice` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_clang`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_clang` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_clang` DISABLE KEYS;
INSERT INTO `sly_clang` VALUES (1,'deutsch','de_DE',0);
ALTER TABLE `sly_clang` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_file`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `re_file_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `attributes` text,
  `filetype` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `originalname` varchar(255) NOT NULL,
  `filesize` int(10) unsigned NOT NULL,
  `width` int(10) unsigned NOT NULL,
  `height` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `filename` (`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_file` DISABLE KEYS;
INSERT INTO `sly_file` VALUES (1,0,0,NULL,'image/jpeg','fish.jpg','fish.jpg',95731,500,375,'Triggerfish','0000-00-00 00:00:00','0000-00-00 00:00:00','admin','admin',0),(2,0,0,NULL,'image/jpeg','fish2.jpg','fish2.jpg',110850,500,375,'The unknown Fish','0000-00-00 00:00:00','0000-00-00 00:00:00','admin','admin',0);
ALTER TABLE `sly_file` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_file_category`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_file_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `re_id` int(10) unsigned NOT NULL,
  `path` varchar(255) NOT NULL,
  `attributes` text,
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(255) NOT NULL,
  `updateuser` varchar(255) NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_pac_role_includes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_role_includes` (
  `role_id` bigint(20) unsigned NOT NULL,
  `included_role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`included_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Role Includes Map';
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_pac_roles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Roles';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_roles` DISABLE KEYS;
INSERT INTO `sly_pac_roles` VALUES (3,'Redakteur');
ALTER TABLE `sly_pac_roles` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_pac_roles_destinations_values`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_roles_destinations_values` (
  `destination` varchar(96) NOT NULL,
  `token` varchar(96) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  `value` varchar(96) NOT NULL,
  PRIMARY KEY (`token`,`role_id`,`value`,`destination`),
  KEY `finder` (`destination`,`token`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Permission Values';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_roles_destinations_values` DISABLE KEYS;
INSERT INTO `sly_pac_roles_destinations_values` VALUES ('mediacategory','access',3,'0'),('language','access',3,'1'),('module','add',3,'0'),('apps','backend',3,'1'),('global_settings','backend',3,'1'),('article','edit',3,'0'),('metainfo','edit',3,'1'),('article','editcontent',3,'0'),('article','edittype',3,'0'),('pages','globalsettings',3,'1'),('pages','mediapool',3,'1'),('article','move',3,'0'),('article','publish',3,'0'),('pages','structure',3,'1'),('metainfo','view',3,'1');
ALTER TABLE `sly_pac_roles_destinations_values` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_pac_users_roles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_users_roles` (
  `user_id` varchar(96) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='User Role Map';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_users_roles` DISABLE KEYS;
INSERT INTO `sly_pac_users_roles` VALUES ('2',3);
ALTER TABLE `sly_pac_users_roles` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_registry`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_registry` (
  `name` varchar(255) NOT NULL,
  `value` blob NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_slice`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_slice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(64) NOT NULL,
  `serialized_values` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_slice` DISABLE KEYS;
INSERT INTO `sly_slice` VALUES (1,'wymeditor','{\"html\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/p><p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.<\\/p><p>Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.<\\/p><p>Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.<\\/p><p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis.<\\/p>\"}'),(2,'image','{\"image\":\"fish2.jpg\"}');
ALTER TABLE `sly_slice` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv24_urls`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv24_urls` (
  `namespace` varchar(32) NOT NULL,
  `ident` varchar(32) NOT NULL,
  `article_id` int(10) unsigned NOT NULL,
  `clang` smallint(4) unsigned NOT NULL,
  `path` varchar(128) NOT NULL,
  `url` varchar(2024) NOT NULL,
  `created` datetime NOT NULL,
  `params` varchar(4096) NOT NULL DEFAULT '',
  PRIMARY KEY (`namespace`,`ident`),
  KEY `path` (`path`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv24_urls` DISABLE KEYS;
INSERT INTO `sly_wv24_urls` VALUES ('sally.article','1_1',1,1,'|','http://sally/base/','2012-08-26 03:39:09',''),('sally.article','2_1',2,1,'|','http://sally/base/wie-sally-fuer-sie-arbeitet/','2012-08-26 03:39:09',''),('sally.article','3_1',3,1,'|','http://sally/base/was-sally-einfach-besser-macht/','2012-08-26 03:39:09',''),('sally.article','4_1',4,1,'|','http://sally/base/warum-unsere-sally/','2012-08-26 03:39:09',''),('sally.article','5_1',5,1,'|','http://sally/base/antwort-auf-ihre-fragen/','2012-08-26 03:39:09',''),('sally.article','6_1',6,1,'|','http://sally/base/kontakt.html','2012-08-26 03:39:09',''),('sally.article','7_1',7,1,'|','http://sally/base/ueber-sally.html','2012-08-26 03:39:09',''),('sally.article','8_1',8,1,'|','http://sally/base/impressum.html','2012-08-26 03:39:09','');
ALTER TABLE `sly_wv24_urls` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv2_meta`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv2_meta` (
  `object_id` int(10) unsigned NOT NULL,
  `clang` int(10) unsigned NOT NULL,
  `metainfo` varchar(64) NOT NULL,
  `meta_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`object_id`,`clang`,`metainfo`,`meta_type`),
  KEY `meta_type` (`meta_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv2_meta` DISABLE KEYS;
INSERT INTO `sly_wv2_meta` VALUES (1,1,'page',0,NULL),(2,1,'page',0,NULL),(3,1,'page',0,NULL),(4,1,'page',0,NULL),(5,1,'page',0,NULL),(6,1,'page',0,NULL),(7,1,'page',0,NULL),(8,1,'page',0,NULL);
ALTER TABLE `sly_wv2_meta` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv8_values`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv8_values` (
  `namespace` varchar(96) NOT NULL,
  `name` varchar(96) NOT NULL,
  `values` text NOT NULL,
  PRIMARY KEY (`namespace`,`name`),
  KEY `namespace` (`namespace`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv8_values` DISABLE KEYS;
INSERT INTO `sly_wv8_values` VALUES ('project','about','{\"1\":null}'),('project','contact','{\"1\":null}'),('project','imprint','{\"1\":null}'),('realurl2','cleanup','{\"1\":1}'),('realurl2','lowercase','{\"1\":1}');
ALTER TABLE `sly_wv8_values` ENABLE KEYS;

SET TIME_ZONE = @OLD_TIME_ZONE;
SET SQL_MODE = @OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS = @OLD_UNIQUE_CHECKS;
SET CHARACTER_SET_CLIENT = @OLD_CHARACTER_SET_CLIENT;
SET CHARACTER_SET_RESULTS = @OLD_CHARACTER_SET_RESULTS;
SET COLLATION_CONNECTION = @OLD_COLLATION_CONNECTION;
SET SQL_NOTES = @OLD_SQL_NOTES;
