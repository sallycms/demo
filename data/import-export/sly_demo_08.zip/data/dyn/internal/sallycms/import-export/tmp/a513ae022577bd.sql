-- Sally Database Dump Version 0.8.*
-- Prefix sly_

SET @OLD_CHARACTER_SET_CLIENT = @@CHARACTER_SET_CLIENT;
SET @OLD_CHARACTER_SET_RESULTS = @@CHARACTER_SET_RESULTS;
SET @OLD_COLLATION_CONNECTION = @@COLLATION_CONNECTION;
SET NAMES utf8;
SET @OLD_TIME_ZONE = @@TIME_ZONE;
SET TIME_ZONE = '+00:00';
SET @OLD_UNIQUE_CHECKS = @@UNIQUE_CHECKS, UNIQUE_CHECKS = 0;
SET @OLD_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS = 0;
SET @OLD_SQL_MODE = @@SQL_MODE, SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';
SET @OLD_SQL_NOTES = @@SQL_NOTES, SQL_NOTES = 0;

DROP TABLE IF EXISTS `sly_article`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_article` (
  `id` int(10) unsigned NOT NULL,
  `clang` int(10) unsigned NOT NULL,
  `re_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `catname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `catpos` int(10) unsigned NOT NULL,
  `attributes` text COLLATE utf8_unicode_ci NOT NULL,
  `startpage` tinyint(1) NOT NULL,
  `pos` int(10) unsigned NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(10) unsigned NOT NULL,
  `type` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updateuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  `wv24_fragment` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `wv24_skip` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`clang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_article` DISABLE KEYS;
INSERT INTO `sly_article` VALUES (1,1,0,'Willkommen','Willkommen',1,'',1,1,'|',1,'default','2013-01-27 00:46:16','2013-03-09 07:06:39','admin','admin',0,'',0),(2,1,0,'Release History','Release History',2,'',1,1,'|',1,'default','2013-01-27 00:46:22','2013-03-09 07:07:42','admin','admin',0,'',0),(3,1,0,'Features','Features',3,'',1,1,'|',1,'default','2013-01-27 00:46:28','2013-03-09 07:08:13','admin','admin',0,'',0),(5,1,0,'Fragen und Antworten','Fragen und Antworten',4,'',1,1,'|',1,'default','2013-01-27 00:46:39','2013-03-09 06:58:23','admin','admin',0,'',0),(8,1,0,'Bildnachweise','',0,'',0,1,'|',1,'default','2013-01-27 00:46:53','2013-03-09 06:55:32','admin','admin',0,'',0),(9,1,2,'Version 0.8','Release History',0,'',0,2,'|2|',1,'news','2013-03-09 06:01:49','2013-03-09 06:12:43','admin','admin',0,'',0),(10,1,2,'Version 0.7','Release History',0,'',0,3,'|2|',1,'news','2013-03-09 06:01:56','2013-03-09 06:31:45','admin','admin',0,'',0),(11,1,2,'Version 0.6','Release History',0,'',0,4,'|2|',1,'news','2013-03-09 06:02:03','2013-03-09 06:08:45','admin','admin',0,'',0);
ALTER TABLE `sly_article` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_article_slice`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_article_slice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `clang` int(10) unsigned NOT NULL,
  `slot` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `pos` int(10) unsigned NOT NULL,
  `slice_id` int(10) unsigned NOT NULL DEFAULT '0',
  `article_id` int(10) unsigned NOT NULL,
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updateuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `find_article` (`article_id`,`clang`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_article_slice` DISABLE KEYS;
INSERT INTO `sly_article_slice` VALUES (1,1,'main',0,1,1,'2013-01-27 01:01:40','2013-03-09 07:06:39','admin','admin',0),(2,1,'main',0,2,3,'2013-01-27 01:11:43','2013-03-09 07:08:13','admin','admin',0),(3,1,'main',0,3,2,'2013-01-27 01:15:15','2013-03-09 07:07:42','admin','admin',0),(7,1,'main',1,7,2,'2013-03-09 06:05:44','2013-03-09 06:05:44','admin','admin',0),(8,1,'main',0,8,11,'2013-03-09 06:08:45','2013-03-09 06:08:45','admin','admin',0),(9,1,'main',0,9,10,'2013-03-09 06:09:45','2013-03-09 06:09:45','admin','admin',0),(10,1,'main',1,10,10,'2013-03-09 06:11:01','2013-03-09 06:31:45','admin','admin',0),(11,1,'main',0,11,9,'2013-03-09 06:12:43','2013-03-09 06:12:43','admin','admin',0),(12,1,'main',0,12,5,'2013-03-09 06:34:25','2013-03-09 06:35:53','admin','admin',0),(13,1,'main',1,13,5,'2013-03-09 06:36:43','2013-03-09 06:37:02','admin','admin',0),(14,1,'main',2,14,5,'2013-03-09 06:40:05','2013-03-09 06:58:23','admin','admin',0),(15,1,'main',0,15,8,'2013-03-09 06:44:25','2013-03-09 06:48:02','admin','admin',0),(16,1,'main',1,16,8,'2013-03-09 06:46:35','2013-03-09 06:50:15','admin','admin',0),(17,1,'main',2,17,8,'2013-03-09 06:47:00','2013-03-09 06:48:06','admin','admin',0),(18,1,'main',3,18,8,'2013-03-09 06:47:42','2013-03-09 06:51:55','admin','admin',0),(19,1,'main',5,19,8,'2013-03-09 06:51:22','2013-03-09 06:51:22','admin','admin',0),(20,1,'main',4,20,8,'2013-03-09 06:52:16','2013-03-09 06:52:16','admin','admin',0),(21,1,'main',7,21,8,'2013-03-09 06:53:28','2013-03-09 06:53:28','admin','admin',0),(22,1,'main',9,22,8,'2013-03-09 06:54:16','2013-03-09 06:54:16','admin','admin',0),(23,1,'main',11,23,8,'2013-03-09 06:55:02','2013-03-09 06:55:02','admin','admin',0),(24,1,'main',10,24,8,'2013-03-09 06:55:11','2013-03-09 06:55:11','admin','admin',0),(25,1,'main',8,25,8,'2013-03-09 06:55:21','2013-03-09 06:55:21','admin','admin',0),(26,1,'main',6,26,8,'2013-03-09 06:55:32','2013-03-09 06:55:32','admin','admin',0);
ALTER TABLE `sly_article_slice` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_clang`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_clang` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `locale` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_clang` DISABLE KEYS;
INSERT INTO `sly_clang` VALUES (1,'deutsch','de_DE',0);
ALTER TABLE `sly_clang` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_file`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `re_file_id` int(10) unsigned NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `attributes` text COLLATE utf8_unicode_ci,
  `filetype` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `originalname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `filesize` int(10) unsigned NOT NULL,
  `width` int(10) unsigned NOT NULL,
  `height` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updateuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `filename` (`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_file` DISABLE KEYS;
INSERT INTO `sly_file` VALUES (3,0,0,'','image/jpeg','five-days.jpg','five-days.jpg',549492,1024,1024,'\"5 days\" von DomiKetu','2013-03-09 06:36:27','2013-03-09 06:59:43','admin','admin',0),(4,0,0,'','image/jpeg','forget-me-nots.jpg','forget-me-nots.jpg',297180,1024,641,'\"Bokeh - Flowers - Forget-me-nots\" von blmiers2','2013-03-09 06:36:27','2013-03-09 06:59:58','admin','admin',0),(5,0,0,'','image/jpeg','pampa.jpg','pampa.jpg',696902,1024,740,'\"Skies and fields from Argentina\'s pampa 22\" von Claudio.Ar','2013-03-09 06:36:27','2013-03-09 07:00:13','admin','admin',0),(6,0,0,'','image/jpeg','pygmy-hedgehog.jpg','pygmy-hedgehog.jpg',91178,640,640,'\"african pygmy hedgehog\" von Adam Foster','2013-03-09 06:36:27','2013-03-09 07:00:26','admin','admin',0),(7,0,0,'','image/jpeg','toucan-eye.jpg','toucan-eye.jpg',214839,1024,683,'\"Toucan eye\" von @Doug88888','2013-03-09 06:36:27','2013-03-09 07:00:39','admin','admin',0),(8,0,0,'','image/jpeg','water-for-life.jpg','water-for-life.jpg',151193,640,427,'\"Water for Life\" von Fadzly @ Shutterhack','2013-03-09 06:36:27','2013-03-09 07:00:54','admin','admin',0);
ALTER TABLE `sly_file` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_file_category`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_file_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `re_id` int(10) unsigned NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `attributes` text COLLATE utf8_unicode_ci,
  `createdate` datetime NOT NULL,
  `updatedate` datetime NOT NULL,
  `createuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updateuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `revision` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_pac_role_includes`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_role_includes` (
  `role_id` bigint(20) unsigned NOT NULL,
  `included_role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`included_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Role Includes Map';
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_pac_roles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Roles';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_roles` DISABLE KEYS;
INSERT INTO `sly_pac_roles` VALUES (1,'Redakteur');
ALTER TABLE `sly_pac_roles` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_pac_roles_destinations_values`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_roles_destinations_values` (
  `destination` varchar(96) NOT NULL,
  `token` varchar(96) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  `value` varchar(96) NOT NULL,
  PRIMARY KEY (`token`,`role_id`,`value`,`destination`),
  KEY `finder` (`destination`,`token`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Permission Values';
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_pac_roles_destinations_values` DISABLE KEYS;
INSERT INTO `sly_pac_roles_destinations_values` VALUES ('mediacategory','access',1,'0'),('language','access',1,'1'),('module','add',1,'0'),('apps','backend',1,'1'),('global_settings','backend',1,'1'),('module','delete',1,'0'),('article','edit',1,'0'),('module','edit',1,'0'),('metainfo','edit',1,'1'),('article','editcontent',1,'0'),('article','edittype',1,'0'),('pages','globalsettings',1,'1'),('pages','mediapool',1,'1'),('article','move',1,'0'),('module','move',1,'0'),('article','publish',1,'0'),('pages','structure',1,'1'),('metainfo','view',1,'1');
ALTER TABLE `sly_pac_roles_destinations_values` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_pac_users_roles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_pac_users_roles` (
  `user_id` varchar(96) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='User Role Map';
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_registry`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_registry` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` blob NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

DROP TABLE IF EXISTS `sly_slice`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_slice` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `serialized_values` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_slice` DISABLE KEYS;
INSERT INTO `sly_slice` VALUES (1,'wymeditor','{\"html\":\"<h3>Willkommen bei SallyCMS<\\/h3><p>Sally CMS ist ein flexibles, performantes und erweiterbares Content Management System (CMS). Sally richtet sich an professionelle Entwickler und Integratoren, die damit Webprojekte umsetzen wollen. Die Weiterentwicklung findet agil mit kurzen, schnellen Releasezyklen und dadurch schneller Fehlerbeseitigung statt. Sally f\\u00fcgt sich hervorragend in Entwicklungsumgebungen ein, in denen mehrere Entwicklung gemeinsan an einem Projekt arbeiten. Auch die modulare Architektur tr\\u00e4gt dazu bei.<\\/p><p>F\\u00fcr Redakteure ist Sally einfach und schnell zu verstehen, ohne das umfangreiche Schulungen notwendig sind. Innerhalb von einer Stunde ist man auch als Neuling in der Lage, die Inhalte seiner Website zu \\u00e4ndern und zu erg\\u00e4nzen.<\\/p><p>Sally wird unter MIT-Lizenz ver\\u00f6ffentlicht und ist dadurch problemlos f\\u00fcr kommerzielle Projekte einsetzbar.<\\/p>\"}'),(2,'wymeditor','{\"html\":\"<h3>Features &amp; Goodies<\\/h3><p>Sally bietet unter anderem \\u2026<\\/p><ul><li>hohe Performance,<\\/li><li>niedrigen System-Overhead,<\\/li><li>eine saubere MVC-Architektur,<\\/li><li>systemweites Caching mit APC\\/Memcache\\/Dateisystem\\/...,<\\/li><li>alle Vorteile des <a href=\\\"https:\\/\\/getcomposer.org\\/#\\\">Composer<\\/a>-\\u00d6kosystems,<\\/li><li>ein 100% frei gestaltbares Frontend zusammen mit<\\/li><li>einem \\u00fcbersichtlichen, erweiterbaren Backend,<\\/li><li>Erweiterbarkeit durch AddOns und Projektcode,<\\/li><li>native Mehrsprachigkeit im Frontend wie Backend,<\\/li><li>ein flexibles, rollenbasiertes Rechtesystem,<\\/li><li>eine klare Trennung zwischen Entwickler und Redakteur,<\\/li><li>exzellente Unterst\\u00fctzung f\\u00fcr das Versionieren von Projekten mit Git\\/Mercurial,<\\/li><li>kurze Entwicklungszyklen und h\\u00e4ufige Releases,<\\/li><li>vollst\\u00e4ndig MIT-lizenzierten und daher problemlos kommerziell einsetzbaren Code,<\\/li><li>... und nat\\u00fcrlich Kompatibilit\\u00e4t mit PHP 5.2 bis 5.5.<\\/li><\\/ul>\"}'),(3,'wymeditor','{\"html\":\"<h3>Release History<\\/h3><p>SallyCMS verfolgt eine Rapid-Release-Philosophie, bei der in der Regel im Abstand von einem halben Jahr eine neue Hauptversion erscheint. Da die API in vielen Teilen noch sehr fl\\u00fcchtig ist, werden Hauptversionen mit einer f\\u00fchrenden 0 gekennzeichnet. Ein Sprung von 0.7 auf 0.8 ist also ein Major-Sprung, von 0.8.0 auf 0.8.1 sind nur Bugfixes und kompatible API-Erweiterungen zu erwarten.<\\/p>\"}'),(7,'newsList','[]'),(8,'wymeditor','{\"html\":\"<p>Das Sally-Team freut sich, die Verf\\u00fcgbarkeit von <strong>SallyCMS 0.6<\\/strong> bekannt zu geben. Dieses Release stellt einen gro\\u00dfen Schritt in Richtung GPL-Freiheit, Vereinheitlichung bestehender Features und neues Backend dar. Seit der Ver\\u00f6ffentlichung von Version 0.5 im August 2011 sind \\u00fcber <strong>550 Commits<\\/strong> von 4 Committern in die Entwicklung geflossen.<\\/p>\"}'),(9,'wymeditor','{\"html\":\"<p>Gut ein halbes Jahr nach dem Release der letzten gro\\u00dfen Major-Version freut sich das Sally-Team, nun die Verf\\u00fcgbarkeit von <strong>SallyCMS 0.7<\\/strong> bekanntzugeben. Das neue Major Release konzentriert sich vor allem auf die Composer-Integration, \\u00fcber die zuk\\u00fcnftig AddOns, Plugins und weitere Bibliotheken in Sally integriert werden, sowie den Wechsel von Scaffold hin zu LESS. Gleichzeitig stellt es das erste Release dar, dass <strong>vollst\\u00e4ndig MIT-lizenziert<\\/strong> ist.<\\/p>\"}'),(10,'wymeditor','{\"html\":\"<h3>Composer-Integration<\\/h3><p>Die Umstellung auf Composer ist sicherlich die deutlichste \\u00c4nderung an diesem Release, da sie die Art und Weise ver\\u00e4ndert, wie Sally externe Bibliotheken (BabelCache, sfYaml, ...) sowie AddOns und Plugins einbindet, installiert und aktualisiert.<\\/p><p>Bisher waren die ben\\u00f6tigten Bibliotheken als Kopie im Sally-Repository enthalten. Nun werden sie erst beim Installieren eines Projekts aus dem Netz heruntergeladen und installiert. Ebenso wird mit AddOns verfahren.<\\/p><p>Eine vollst\\u00e4ndige Erkl\\u00e4rung von Composer sprengt den Rahmen der Release Notes und soll daher nicht stattfinden. Im Netz gibt es eine ganze Reihe n\\u00fctzlicher Artikel und Websites zu Composer:<\\/p><ul><li><a href=\\\"http:\\/\\/getcomposer.org\\/#\\\">Die Composer-Website<\\/a><\\/li><li><a href=\\\"http:\\/\\/nelm.io\\/blog\\/2011\\/12\\/composer-part-1-what-why\\/#\\\">Composer: What &amp; Why (Part 1)<\\/a> und <a href=\\\"http:\\/\\/nelm.io\\/blog\\/2011\\/12\\/composer-part-2-impact\\/#\\\">Part 2<\\/a><\\/li><\\/ul><p>Wir m\\u00f6chten betonen, dass niemand zum Einsatz von Composer gezwungen wird. Es ist weiterhin m\\u00f6glich, Projekte g\\u00e4nzlich ohne Composer aufzusetzen, zu entwickeln und deployen. Im Abschnitt Non-Composer weiter unten sind dazu weitere Details.<\\/p>\"}'),(11,'wymeditor','{\"html\":\"<p>Knapp f\\u00fcnf Monate nach dem Release der letzten gro\\u00dfen Major-Version freut sich das Sally-Team, nun die Verf\\u00fcgbarkeit von <strong>SallyCMS 0.8<\\/strong> bekanntzugeben. Das neue Major Release treibt vor allem die Composer-Integration weiter voran und f\\u00fchrt dazu ein neues, an Symfony2 angelegtes Repository-System ein.<\\/p><p>Neben der verbesserten Composer-Integration bringt Version 0.8 ebenfalls noch ein von Grund auf <strong>neu entwickeltes Setup<\\/strong>, einen <strong>Dependency Injection<\\/strong>-Container, eine <strong>CLI-Console<\\/strong>, einen integrierten <strong>CSRF-Schutz<\\/strong> sowie ein flexibles <strong>Backend-Routing<\\/strong> mit.<\\/p>\"}'),(12,'wymeditor','{\"html\":\"<h3>Fragen und Antworten<\\/h3><p>Das Sally-Team freut sich \\u00fcber Anregungen und steht bei Problemen gern zur Verf\\u00fcgung. Wenn zum Beispiel bei der Nutzung von Modulen wie dieser Galerie ...<\\/p>\"}'),(13,'gallery','{\"title\":\"Creative Commons at its Best\",\"images\":\"water-for-life.jpg,toucan-eye.jpg,pygmy-hedgehog.jpg,pampa.jpg,forget-me-nots.jpg,five-days.jpg,pygmy-hedgehog.jpg\"}'),(14,'wymeditor','{\"html\":\"<p>... Fragen oder Probleme auftreten, ist das <strong><a href=\\\"https:\\/\\/projects.webvariants.de\\/projects\\/sallycms\\/boards#\\\">Forum<\\/a><\\/strong> die richtige Anlaufstelle.<\\/p><p>Bei handfesteren Problemen, die sich eher als Bugs bemerkbar machen, ist der <strong><a href=\\\"https:\\/\\/bitbucket.org\\/SallyCMS\\/sallycms\\/issues#\\\">Bugtracker bei Bitbucket<\\/a><\\/strong> das Tool der Wahl.<\\/p><p>Offizielle Neuigkeiten werden \\u00fcber die <strong><a href=\\\"https:\\/\\/plus.google.com\\/b\\/114660281857431220675\\/#\\\">Google+ Page<\\/a><\\/strong> bekanntgegeben; bei Google+ befindet sich auch die <strong><a href=\\\"https:\\/\\/plus.google.com\\/communities\\/106373608286910254172#\\\">Sally-Community<\\/a><\\/strong>.<\\/p>\"}'),(15,'image','{\"image\":\"five-days.jpg\"}'),(16,'wymeditor','{\"html\":\"<h3>\\\"5 days\\\"<\\/h3><p style=\\\"margin-bottom:25px\\\">von <a href=\\\"http:\\/\\/www.flickr.com\\/photos\\/50764698@N05\\/4976097279\\/#\\\">DomiKetu<\\/a>,&#160;CC BY-NC-ND 2.0<\\/p>\"}'),(17,'image','{\"image\":\"forget-me-nots.jpg\"}'),(18,'wymeditor','{\"html\":\"<h3>\\\"Bokeh - Flowers - Forget-me-nots\\\"<\\/h3><p style=\\\"margin-bottom:25px\\\">von <a href=\\\"http:\\/\\/www.flickr.com\\/photos\\/41304517@N00\\/5777659359\\/#\\\">blmiers2<\\/a>,&#160;CC BY-NC-SA 2.0<\\/p>\"}'),(19,'wymeditor','{\"html\":\"<h3>\\\"Skies and fields from Argentina\'s pampa 22\\\"<\\/h3><p style=\\\"margin-bottom:25px\\\">von <a href=\\\"http:\\/\\/www.flickr.com\\/photos\\/8991878@N08\\/3072552750\\/\\\">Claudio.Ar<\\/a>, CC BY-NC-SA 2.0<\\/p>\"}'),(20,'image','{\"image\":\"pampa.jpg\"}'),(21,'wymeditor','{\"html\":\"<h3>\\\"african pygmy hedgehog\\\"<\\/h3><p style=\\\"margin-bottom:25px\\\">von <a href=\\\"http:\\/\\/www.flickr.com\\/photos\\/26304233@N00\\/4301471586\\/\\\">Adam Foster | Codefor<\\/a>, CC BY-NC-ND 2.0<\\/p>\"}'),(22,'wymeditor','{\"html\":\"<h3>\\\"Toucan eye\\\"<\\/h3><p style=\\\"margin-bottom:25px\\\">von <a href=\\\"http:\\/\\/www.flickr.com\\/photos\\/doug88888\\/4178931297\\/\\\">@Doug88888<\\/a>, CC BY-NC-SA 2.0<\\/p>\"}'),(23,'wymeditor','{\"html\":\"<h3>\\\"Water for Life\\\"<\\/h3><p style=\\\"margin-bottom:25px\\\">von <a href=\\\"http:\\/\\/www.flickr.com\\/photos\\/9352758@N04\\/2121437918\\/\\\">Fadzly @ Shutterhack<\\/a>, CC BY-NC-ND 2.0<\\/p>\"}'),(24,'image','{\"image\":\"water-for-life.jpg\"}'),(25,'image','{\"image\":\"toucan-eye.jpg\"}'),(26,'image','{\"image\":\"pygmy-hedgehog.jpg\"}');
ALTER TABLE `sly_slice` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv24_urls`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv24_urls` (
  `namespace` varchar(32) NOT NULL,
  `ident` varchar(32) NOT NULL,
  `article_id` int(10) unsigned NOT NULL,
  `clang` smallint(4) unsigned NOT NULL,
  `path` varchar(128) NOT NULL,
  `url` varchar(2024) NOT NULL,
  `created` datetime NOT NULL,
  `params` varchar(4096) NOT NULL DEFAULT '',
  PRIMARY KEY (`namespace`,`ident`),
  KEY `path` (`path`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv24_urls` DISABLE KEYS;
INSERT INTO `sly_wv24_urls` VALUES ('sally.article','10_1',10,1,'|2|','http://sally/releases/sally-tip-starterkit/sally/release-history/version-0-7.html','2013-03-09 07:06:50',''),('sally.article','11_1',11,1,'|2|','http://sally/releases/sally-tip-starterkit/sally/release-history/version-0-6.html','2013-03-09 07:06:50',''),('sally.article','1_1',1,1,'|','http://sally/releases/sally-tip-starterkit/sally/','2013-03-09 07:06:50',''),('sally.article','2_1',2,1,'|','http://sally/releases/sally-tip-starterkit/sally/release-history/','2013-03-09 07:06:50',''),('sally.article','3_1',3,1,'|','http://sally/releases/sally-tip-starterkit/sally/features/','2013-03-09 08:07:16',''),('sally.article','5_1',5,1,'|','http://sally/releases/sally-tip-starterkit/sally/fragen-und-antworten/','2013-03-09 07:33:44',''),('sally.article','8_1',8,1,'|','http://sally/releases/sally-tip-starterkit/sally/bildnachweise.html','2013-03-09 07:43:30',''),('sally.article','9_1',9,1,'|2|','http://sally/releases/sally-tip-starterkit/sally/release-history/version-0-8.html','2013-03-09 07:06:50','');
ALTER TABLE `sly_wv24_urls` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv2_meta`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv2_meta` (
  `object_id` int(10) unsigned NOT NULL,
  `clang` int(10) unsigned NOT NULL,
  `metainfo` varchar(64) NOT NULL,
  `meta_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`object_id`,`clang`,`metainfo`,`meta_type`),
  KEY `meta_type` (`meta_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv2_meta` DISABLE KEYS;
INSERT INTO `sly_wv2_meta` VALUES (1,1,'page',0,NULL),(2,1,'page',0,NULL),(3,1,'page',0,NULL),(5,1,'page',0,NULL),(8,1,'page',0,NULL),(9,1,'author',0,'SallyCMS Team'),(9,1,'date',0,'1363474800'),(10,1,'author',0,'SallyCMS-Team'),(10,1,'date',0,'1349215200'),(11,1,'author',0,'SallyCMS-Team'),(11,1,'date',0,'1329174000');
ALTER TABLE `sly_wv2_meta` ENABLE KEYS;

DROP TABLE IF EXISTS `sly_wv8_values`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `sly_wv8_values` (
  `namespace` varchar(96) NOT NULL,
  `name` varchar(96) NOT NULL,
  `values` text NOT NULL,
  PRIMARY KEY (`namespace`,`name`),
  KEY `namespace` (`namespace`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

ALTER TABLE `sly_wv8_values` DISABLE KEYS;
INSERT INTO `sly_wv8_values` VALUES ('project','about','{\"1\":\"3\"}'),('project','contact','{\"1\":\"5\"}'),('project','images','{\"1\":\"8\"}'),('realurl2','cleanup','{\"1\":1}'),('realurl2','lowercase','{\"1\":1}');
ALTER TABLE `sly_wv8_values` ENABLE KEYS;

SET TIME_ZONE = @OLD_TIME_ZONE;
SET SQL_MODE = @OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS = @OLD_UNIQUE_CHECKS;
SET CHARACTER_SET_CLIENT = @OLD_CHARACTER_SET_CLIENT;
SET CHARACTER_SET_RESULTS = @OLD_CHARACTER_SET_RESULTS;
SET COLLATION_CONNECTION = @OLD_COLLATION_CONNECTION;
SET SQL_NOTES = @OLD_SQL_NOTES;
